<?php

declare(strict_types=1);

namespace ClutchCore;

use pocketmine\Player;
use pocketmine\entity\Living;
use ClutchCore\CustomPlayer;

class CustomNPC extends Living {


    public $plugin;
    public $player;

    /**
     * @param Main $main
     * @param CustomPlayer $player
     * @return void
     */

    public function __construct(Main $plugin, CustomPlayer $player){

        parent::initEntity();

        $this->player = $player;
        $this->plugin = $plugin;
        
        $this->setNametag("§r§8Clutch Trainer");
        $this->setMaxHealth("20");
        $this->setHealth("20");
        $this->generateRandomPosition();
    }

    public function getName() : string{
        return "CustomNPC";
    }

    public function getPlayer(){
        return $this->player;
    }

    public function getNameTag():string{
        return "CustomNPC";
    }

    public function setPlayer(CustomPlayer $player) : void{
        $this->player = $player;
    }
}