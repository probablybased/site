<?php

namespace ClutchCore\task;

use Bumy\LobbyCore\Main;
use pocketmine\Player;
use ClutchCore\CustomPlayer;
use pocketmine\scheduler\Task;

class DoubleHitTask extends Task{

    public $plugin;
    public $player;

    public function __construct(Main $plugin, CustomPlayer $player){
        $this->plugin = $plugin;
        $this->player = $player;
    }

    public function onRun(int $currentTick){
        $this->plugin->getArenaManager()->doSecondHit($this->player);
    }
}