<?php

declare(strict_types=1);

namespace ClutchCore;

use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\Player;
use pocketmine\entity\Human;
use ClutchCore\CustomNPC;

class CustomPlayer extends Player {

    public $plugin;

    //Declares if the hits are coming or the game is stopped
    public $inGame = false;
    public $npc;

    /**
     * @param Main $main
     * @return void
     */
	public function load(Main $main) : void {
		$this->plugin = $main;
        //create hitting npc
        $this->npc = new CustomNPC($main, $this);
        $this->npc->setMaxHealth("20");
        $this->npc->setHealth("20");
        $this->npc->setNametag("§r§8Clutch Trainer");
        $this->npc->generateRandomPosition();
	}

    /**
     * @param EntityDamageEvent $source
     * @return void
     */
	public function attack(EntityDamageEvent $source) : void {
        parent::attack($source);
        
        if($source->isCancelled()) return;

        $this->attackTime = 10;

        if($this->getGamemode() == 2 or $this->getGamemode() == 3){
            $source->setCancelled(true);
            return;
        }

        if($source instanceof EntityDamageByChildEntityEvent){
        	$damager = $source->getDamager();
        }elseif($source->getCause() === EntityDamageEvent::CAUSE_ENTITY_EXPLOSION){
        	$damager = $source->getDamager();
        }else{
        	$damager = $source->getDamager();
        }

        if($source->getCause() === EntityDamageEvent::CAUSE_FALL or $source->getCause() === EntityDamageEvent::CAUSE_SUFFOCATION){
            $source->setCancelled(true);
            return;
        }else{
            if($source->getCause() !== EntityDamageEvent::CAUSE_ENTITY_ATTACK and !$source instanceof EntityDamageByChildEntityEvent and $source->getCause() !== EntityDamageEvent::CAUSE_ENTITY_EXPLOSION){
                $source->setCancelled(false);
                $source->setKnockBack(0.4);
            } 
        }
    }

    public function getInGame() : bool{
        return $this->inGame;
    }

    public function setInGame(bool $bool) : void{
        $this->inGame = $bool;
    }

    public function getNPC(){
        return $this->npc;
    }

    public function setNPC($npc){
        $this->npc = $npc;
    }
}
