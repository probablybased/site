<?php

declare(strict_types = 1);

namespace ClutchCore;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;

use pocketmine\Server;
use pocketmine\Player;

use ClutchCore\CustomPlayer;
use ClutchCore\ArenaManager;
use ClutchCore\CustomNPC;

class Main extends PluginBase implements Listener {

    public $arenaManager;

    public function onEnable() {

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->arenaManager = new ArenaManager($this);

        //create task or not

        #loading all worlds
        foreach(glob($this->getServer()->getDataPath() . "worlds/*") as $world) {
            $world = str_replace($this->getServer()->getDataPath() . "worlds/", "", $world);
            if($this->getServer()->isLevelLoaded($world)){
                continue;
            }
            $this->getServer()->loadLevel($world);
        }

        $this->getServer()->getCommandMap()->registerAll("astral", [
            #new commands\Test("test", $this),
        ]);
    }

    /**
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function onPlayerCreation(PlayerCreationEvent $event) : void{
        $event->setPlayerClass(CustomPlayer::class);

    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoin(PlayerJoinEvent $event) : void{
        $player = $event->getPlayer();
        $player->load($this);
        $this->getArenaManager()->createGame($player);
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onPlayerLeave(PlayerQuitEvent $event) : void{
        $player = $event->getPlayer();
        //delete game and map

    }

    public function onEntityDamageEvent(EntityDamageEvent $event){
        //cancelling customnpc hit
        if($event instanceof EntityDamageByEntityEvent){
            if($event->getEntity() instanceof CustomNPC){
                $event->setCancelled();
            }
        }
    }

    /**
     * @param CustomPlayer $player
     * @param $folderName
     * @return void
     */
    public function createMap(CustomPlayer $player, $folderName){
        $mapname = $folderName."-".$player->getName();
      
        $zipPath = $this->getServer()->getDataPath() . "plugin_data/ClutchCore/" .  $folderName . ".zip";

        if(file_exists($this->getServer()->getDataPath() . "worlds" . DIRECTORY_SEPARATOR . $mapname)){
            $this->deleteMap($player, $folderName);
        }
      
        $zipArchive = new \ZipArchive();
        if($zipArchive->open($zipPath) == true){
            $zipArchive->extractTo($this->getServer()->getDataPath() . "worlds");
            $zipArchive->close();
          $this->getLogger()->notice("Zip Object created!");
        } else {
          $this->getLogger()->notice("Couldn't create Zip Object!");
        }
        
        rename($this->getServer()->getDataPath() . "worlds" . DIRECTORY_SEPARATOR . $folderName, $this->getServer()->getDataPath() . "worlds" . DIRECTORY_SEPARATOR . $mapname);
        $this->getServer()->loadLevel($mapname);
        return $this->getServer()->getLevelByName($mapname);
    }
    
    /**
     * @param CustomPlayer $player
     * @param $folderName
     * @return void
     */            
    public function deleteMap(CustomPlayer $player, $folderName) : void{
        $mapName = $folderName."-".$player->getName();
        if(!$this->getServer()->isLevelGenerated($mapName)) {
            
            return;
        }

        if(!$this->getServer()->isLevelLoaded($mapName)) {
            
            return;
        }

        $this->getServer()->unloadLevel($this->getServer()->getLevelByName($mapName));
        $folderName = $this->getServer()->getDataPath() . "worlds" . DIRECTORY_SEPARATOR . $mapName;
        $this->removeDirectory($folderName);
        
         $this->getLogger()->notice("World has been deleted for player called ".$player->getName());
      
    }

    public function removeDirectory($path) {
        $files = glob($path . '/*');
        foreach ($files as $file) {
            is_dir($file) ? $this->removeDirectory($file) : unlink($file);
        }
        rmdir($path);
        return;
    }

    public function getArenaManager(){
        return $this->arenaManager;
    }
               
}
