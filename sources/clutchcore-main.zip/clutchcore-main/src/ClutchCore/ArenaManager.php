<?php

declare(strict_types=1);

namespace ClutchCore;

use ClutchCore\Main;
use ClutchCore\CustomPlayer;
use ClutchCore\task\HitTask;
use ClutchCore\task\WaitBetweenTask;

use pocketmine\level\Position;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class ArenaManager{

	public $plugin;

    public $maps = ["testMap1", "testMap2"];

	public function __construct(Main $plugin){
        $this->plugin = $plugin;
    }

    public function createGame(CustomPlayer $player){
        //getting a random map from the maps array
    	$map = $this->maps[mt_rand(0, count($this->maps) - 1)];

    	$this->getPlugin()->createMap($player, $map);

    	$pos = new Position(0, 0, 0, $this->getPlugin->getServer()->getLevelByName("mapName-".$player->getName()));
    	$player->teleport($pos);
    }

    public function deleteGame(CustomPlayer $player){
    	//TODO: Change the map name
    	$this->getPlugin()->deleteMap($player, "mapName");
    }

    public function giveItems(CustomPlayer $player, string $phase){
    	$inv = $player->getInventory();
    	switch($phase){
    		case "stopped":
                //TODO: Give items
    			break;

    		case "game":
                //TODO: Give items
    			break;
    	}
    }

    public function startHits(CustomPlayer $player){
        //first hit
        $this->hitPlayer($player);
        //10 is the default delay between hits
    	$this->getScheduler()->scheduleDelayedTask(new task\HitTask($this->plugin, $player), 10);
    }

    public function doSecondHit(CustomPlayer $player){
        //second hit
        $this->hitPlayer($player);
        //next hit "wave" is random from 5 to 10 seconds
    	$this->getScheduler()->scheduleDelayedTask(new task\WaitBetweenTask($this->plugin, $player), mt_rand(5 * 20, 10 * 20));
    }

    //Hit the player by the npc
    public function hitPlayer(CustomPlayer $player){
        $npc = $player->getNPC();
        //Default kb from pocketmine
        $kb = 0.4;
        //attacker, target, cause, dmg, modifiers, kb
        $ev = new EntityDamageByEntityEvent($npc, $player, EntityDamageEvent::CAUSE_ENTITY_ATTACK, 0, [], $kb);
        $player->attack($ev);
    }

    public function getPlugin(){
    	return $this->plugin;
    }

}

