<?php

declare(strict_types=1);

namespace DidntPot\cp\Tasks;

use pocketmine\scheduler\Task;
use DidntPot\cp\Core;
use pocketmine\Player;
use pocketmine\Server;

class PopupTask extends Task{
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}
	
	public function onRun(int $tick){
		foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
			$online->sendTip("§5pvp.astralclient.net§r");
		}
	}
}
