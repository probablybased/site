<?php

declare(strict_types = 1);

namespace DidntPot\cp\tasks;

use pocketmine\scheduler\Task;
use DidntPot\cp\Core;

class MOTDTask extends Task{
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
		$this->line=-1;
	}
	public function onRun(int $tick):void{
    
		$motd=[
		"§l§5BEDWARS",
		"§l§5FIXED PING",
    "§l§5PRACTICE",
		"§l§5NEW KBFFA"
		];
    
		$this->line++;
		$msg = $motd[$this->line];
		$this->plugin->getServer()->getNetwork()->setName($msg);
		if($this->line === count($motd) - 1){
			$this->line = -1;
		}
	}
}
