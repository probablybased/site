<?php

declare(strict_types=1);

namespace DidntPot\cp\Listeners;

use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\event\player\PlayerInteractEvent;

use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\math\Vector3;

use DidntPot\cp\Core;
use DidntPot\cp\Forms\{SimpleForm, CustomForm, ModalForm};
use DidntPot\cp\Listeners\ItemListener;

class PlayerListener implements Listener{
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}
	
	/**
	* @priority HIGHEST
	*/
	function onCraft(CraftItemEvent $event){
		$event->setCancelled();
	}
	
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$event->setJoinMessage("§8[§a+§8]§r§a ". $player->getName());
		$this->broadcastTitle("§5§lAstralPvP§r", "§dpvp.astralclient.net", 5, 10, 7);
		$this->setItems($player);

		$x = 256;
		$y = 71;
		$z = 256;
		$lobby = $this->plugin->getServer()->getLevelByName("lobby");
		$player->teleport(new Vector3($x, $y, $z, 0, 0, $lobby));
		
		//"✅" is for small text, experimental - Peppa.

                //
		$player->sendMessage("§r✅§7----------------------------------------");
		$player->sendMessage("§r");
                $player->sendMessage("§r✅§d§lAstral Network§r");
                $player->sendMessage("§r");
                $player->sendMessage("§r✅§fWelcome to Astral (HUB)");
                $player->sendMessage("§r");
                $player->sendMessage("§r✅§7» Website: astralclient.net");
                $player->sendMessage("§r✅§7» Discord: astralclient.net/discord");
                $player->sendMessage("§r✅§7» Store: store.astralclient.net");
		$player->sendMessage("§r");
		$player->sendMessage("§r✅§7----------------------------------------");
		//
	}

    public function onChat(PlayerChatEvent $ev){
        $p = $ev->getPlayer();
        $ev->setCancelled();
        $p->sendMessage("§d» §cYou cannot chat in Hub!");
    }

    public static function onJoin1(PlayerJoinEvent $ev){
	    $player = $ev->getPlayer();
        $skin = Core::getDataFolder() . "Steve.png";
        $data = '';
        for($y = 0, $height = imagesy($skin); $y < $height; $y++){
            $color = imagecolorat($skin, $x, $y);
            $data .=
                pack("c", ($color >> 16) & 0xFF) .
                pack("c", ($color >> 8) & 0xFF) .
                pack("c", $color & 0xFF) .
                pack("c", 255 - (($color & 0x7F000000) >> 23));
        }
        $player->setSkin($skin);

    }

    /**
     * @param PlayerMoveEvent $event
     */
    public function onMove(PlayerMoveEvent $event) : void
    {
        $player = $event->getPlayer();

                    if($player->getY() < 56){
                        $x = 256;
                        $y = 71;
                        $z = 256;
                    $player->teleport(new Vector3($x, $y, $z));
                    }
                }
	
	public function onQuit(PlayerQuitEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$reason = $event->getQuitReason();
		
		$event->setQuitMessage("§8[§c-§8]§r§c ". $player->getName());
	}
	
	public function onExhaust(PlayerExhaustEvent $event){
		$event->setCancelled();
	}
	
	public function onDrop(PlayerDropItemEvent $event){
		$player = $event->getPlayer();
		$item = $event->getItem();
		$level = $player->getLevel()->getName();
		
		$event->setCancelled();
	}
	
	public function onEntityDamage(EntityDamageEvent $event){
		    $event->setCancelled();
	}
	
	public function setItems(Player $player){
		$player->extinguish();
		$player->setScale(1);
		$player->setGamemode(2);
		$player->setImmobile(false);
		$player->setAllowFlight(false);
		$player->setFlying(false);
		$player->removeAllEffects();
		$player->setXpLevel(0);
		$player->setXpProgress(0.0);
		$player->setFood(20);
		$player->setHealth(20);
		$player->getInventory()->setSize(36);
		$player->getInventory()->clearAll();
		$player->getArmorInventory()->clearAll();
			
		$compass = Item::get(345, 0, 1);
		$compass->setCustomName("§r§l§5SERVER SELECTOR§r");
			
		$vine = Item::get(160, 5, 1);

		//$hub = Item::get(51, 0, 1);
		//$hub->setCustomName("§o§l§dBack To Spawn§r");

		//$info = Item::get(76, 0, 1);
		//$info->setCustomName("§o§l§dComing Soon§r");
			
		$player->getInventory()->setItem(0, $vine);
		$player->getInventory()->setItem(1, $vine);
		$player->getInventory()->setItem(2, $vine);
		$player->getInventory()->setItem(3, $vine);
		$player->getInventory()->setItem(4, $compass);
		$player->getInventory()->setItem(5, $vine);
		$player->getInventory()->setItem(6, $vine);
	        $player->getInventory()->setItem(7, $vine);
		$player->getInventory()->setItem(8, $vine);
			
		$player->getInventory()->setHeldItemIndex(4);
	}
}
