<?php

declare(strict_types=1);

namespace DidntPot\cp\Listeners;

use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;

use pocketmine\item\Item;
use pocketmine\event\player\PlayerInteractEvent;
use alemiz\sga\StarGateAtlantis;
use libpmquery\PMQuery;
use libpmquery\PmQueryException;

use DidntPot\cp\Core;
use DidntPot\cp\Forms\{SimpleForm, CustomForm, ModalForm};
use DidntPot\cp\Listeners\PlayerListener;

use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use waterdog\transfercommand\API;

class ItemListener implements Listener
{

    private $formCd = [];

    public function __construct(Core $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();

        if ($item->getCustomName() == "§r§l§5SERVER SELECTOR§r") {
            $event->setCancelled();
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->tpForm($player);
                $this->levelupSound($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->tpForm($player);
                   $this->levelupSound($player);
                   return;
                }
            }
        }
        if ($item->getCustomName() == "§o§l§dBack To Spawn§r") {
            $event->setCancelled();
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->warphub($player);
                $this->beaconSound($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->warpHub($player);
                    $this->beaconSound($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§o§l§cServer Info§r") {
            $event->setCancelled();
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->infoForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->infoForm($player);
                    return;
                }
            }
        }
    }

    public function warpHub(Player $player): void
    {
        $x = 256;
        $y = 71;
        $z = 256;
        $lobby = $this->plugin->getServer()->getLevelByName("lobby");

        $player->teleport(new Vector3($x, $y, $z, 0, 0, $lobby));
    }

    public function tpForm(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data = null): void {
            switch ($data) {
                case "prac":
                    $this->pracRegionForm($player);
                    break;
                case "bedwar":
                    $player->transfer("45.134.8.12", 25655);
                case "smp":
                    $this->levelupSound($player);
                    $player->transfer("45.134.8.70", 19384);
                case "kb":
                    $name = $player->getName();
                    $player->getServer()->broadcastMessage("§d» §7$name has been transferred to Knockback FFA!");
                    $this->enderGrowlSound($player);
                    $player->transfer("45.134.8.140", 19539);

            }
        });

        $napracquery = PMQuery::query("45.134.8.50", 19140);
        $napracplayers = (int)$napracquery['Players'];

        $bwnapracquery = PMQuery::query("45.134.8.12", 25655);
        $bwnapracplayers = (int)$bwnapracquery['Players'];

        $kbquery = PMQuery::query("45.134.8.140", 19539);
        $kbplayers = (int)$kbquery['Players'];

        $form->setTitle("§7Servers§r");
        $form->addButton("§8§lPractice\n§r§7Playing [$napracplayers]§r", 0, "textures/items/diamond_sword", "prac");
        $form->addButton("§8§lBedwars\n§r§7Playing [$bwnapracplayers]§r", 0, "textures/items/bed", "bedwar");
        $form->addButton("§8§lKnockback FFA\n§r§7Playing [$kbplayers]§r", 0, "textures/items/stick", "kb");

        $player->sendForm($form);
    }

    public function pracRegionForm(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data = null): void {
            switch ($data) {
                case "naprac":
                    $this->confirmNaPrac($player);
                    break;
                case "asprac":
                    $this->confirmAsPrac($player);
                    break;
                case "exit":
                    $this->tpForm($player);
                    break;
            }
        });

        $napracquery = PMQuery::query("45.134.8.50", 19140);
        $napracplayers = (int)$napracquery['Players'];


        $form->setTitle("§8Practice§r");
        $form->addButton("§8§lNA Practice\n§r§7Playing [$napracplayers]§r", 0, "textures/items/diamond_sword", "naprac");
        $form->addButton("§cBack", 0, "", "exit");

        $player->sendForm($form);
    }

    public function bedwarForm(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data = null): void {
            switch ($data) {
                case "nabedwar":

                    $name = $player->getName();
                    $player->getServer()->broadcastMessage("§d» §7$name has been transferred to NA Bedwars!");

                    $player->transfer("45.134.8.12", 25655);

                    break;
                case "asbedwar":
                    break;
            }
        });
        $bwnaquery = PMQuery::query("45.134.8.12", 25655);
        $bwnaplayers = (int)$bwnaquery['Players'];

        $form->setTitle("§8Bedwars§r");
        $form->addButton("§8§lNA Bedwars\n§r§7Playing [$bwnaplayers]§r", 0, "textures/items/bed", "nabedwar");

        $player->sendForm($form);
    }

    public function confirmNaPrac(Player $player): void
    {
        $form = new ModalForm(function (Player $player, $data = null): void {
            switch ($data) {
                case "pracconfirm":

                    $this->explodeSound($player);

                    $name = $player->getName();
                    $player->getServer()->broadcastMessage("§d» §7$name has been transferred to NA Practice!");
                    $player->transfer("45.134.8.50", 19140);

                    break;
                case "pracdecline":
                    $this->tpForm($player);
                    break;
            }
        });
        $form->setTitle("§8Practice§r");
        $form->setContent("§7Please confirm to transfer to Practice [NA]!");
        $form->setButton1("§aConfirm", 0, "pracconfirm");
        $form->setButton2("§cDecline", 0, "pracdecline");

        $player->sendForm($form);
    }
    
    public static function conduitSound(Player $player)
    {
        if (is_null($player)) return;
        $sound1 = new PlaySoundPacket();
        $sound1->soundName = "conduit.activate";
        $sound1->x = $player->getX();
        $sound1->y = $player->getY();
        $sound1->z = $player->getZ();
        $sound1->volume = 10;
        $sound1->pitch = 1;

            $player->dataPacket($sound1);

    }

    public static function beaconSound(Player $player)
    {
        if (is_null($player)) return;
        $sound1 = new PlaySoundPacket();
        $sound1->soundName = "beacon.power";
        $sound1->x = $player->getX();
        $sound1->y = $player->getY();
        $sound1->z = $player->getZ();
        $sound1->volume = 10;
        $sound1->pitch = 1;

        $player->dataPacket($sound1);

    }

    public static function levelupSound(Player $player)
    {
        if (is_null($player)) return;
        $sound1 = new PlaySoundPacket();
        $sound1->soundName = "random.levelup";
        $sound1->x = $player->getX();
        $sound1->y = $player->getY();
        $sound1->z = $player->getZ();
        $sound1->volume = 10;
        $sound1->pitch = 1;

            $player->dataPacket($sound1);

    }

    public static function explodeSound(Player $player)
    {
        if (is_null($player)) return;
        $sound1 = new PlaySoundPacket();
        $sound1->soundName = "random.explode";
        $sound1->x = $player->getX();
        $sound1->y = $player->getY();
        $sound1->z = $player->getZ();
        $sound1->volume = 10;
        $sound1->pitch = 1;
            $player->dataPacket($sound1);

    }

    public static function enderGrowlSound(Player $player)
    {
        if (is_null($player)) return;
        $sound1 = new PlaySoundPacket();
        $sound1->soundName = "mob.enderdragon.growl";
        $sound1->volume = 10;
        $sound1->pitch = 1;
        $sound1->x = $player->getX();
        $sound1->y = $player->getY();
        $sound1->z = $player->getZ();
        $player->dataPacket($sound1);
    }
}
