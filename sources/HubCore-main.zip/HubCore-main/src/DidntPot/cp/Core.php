<?php

declare(strict_types=1);

namespace DidntPot\cp;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

use DidntPot\cp\Tasks\PopupTask;
use DidntPot\cp\Tasks\setname1;
use DidntPot\cp\Tasks\setname3;
use DidntPot\cp\Tasks\setname4;
use DidntPot\cp\Tasks\setname2;
use DidntPot\cp\Listeners\ItemListener;
use DidntPot\cp\Listeners\PlayerListener;

class Core extends PluginBase{
	
	public function onEnable():void{
		
		//$this->getServer()->loadLevel("lobby");
		
		$this->setTasks();
		$this->setListeners();
		
		$this->getLogger()->info("--- AstralPvP Hub ---");
		$this->getServer()->getNetwork()->setName("§5ASTRALPVP");
	}
	
	public static function getInstance():Core{
		return self::$instance;
	}
	
	public function setTasks(){
		$map = $this->getScheduler();
		
		$map->scheduleRepeatingTask(new PopupTask($this), 5);
		$map->scheduleRepeatingTask(new MOTDTask($this), 60);

		$this->getLogger()->info("--- Loaded Tasks ---");
	}
	
	public function setListeners(){
		$map = $this->getServer()->getPluginManager();
		
		$map->registerEvents(new ItemListener($this), $this);
		$map->registerEvents(new PlayerListener($this), $this);
		$this->getLogger()->info("--- Loaded Listeners ---");
	}
	
	public function disableCommands(){
		$map = $this->getServer()->getCommandMap();
		
		$map->unregister($map->getCommand("kill"));
		$map->unregister($map->getCommand("me"));
		$map->unregister($map->getCommand("op"));
		$map->unregister($map->getCommand("deop"));
		$map->unregister($map->getCommand("enchant"));
		$map->unregister($map->getCommand("effect"));
		$map->unregister($map->getCommand("defaultgamemode"));
		$map->unregister($map->getCommand("difficulty"));
		$map->unregister($map->getCommand("spawnpoint"));
		$map->unregister($map->getCommand("setworldspawn"));
		$map->unregister($map->getCommand("title"));
		$map->unregister($map->getCommand("seed"));
		$map->unregister($map->getCommand("particle"));
		$map->unregister($map->getCommand("gamemode"));
		$map->unregister($map->getCommand("tell"));
		$map->unregister($map->getCommand("say"));
	}
}
