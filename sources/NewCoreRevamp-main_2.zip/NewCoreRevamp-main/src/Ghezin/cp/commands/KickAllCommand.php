<?php

declare(strict_types=1);

namespace Ghezin\cp\Commands;

use pocketmine\Player;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use Ghezin\cp\Core;
use waterdog\transfercommand\API;

class KickAllCommand extends PluginCommand{
	
	private $plugin;
	
	public function __construct(Core $plugin){
		parent::__construct("kickall", $plugin);
		$this->plugin=$plugin;
		$this->setPermission("cp.command.kickall");
	}
	public function execute(CommandSender $player, string $commandLabel, array $args){
		if(!$player->isOp()){
			$player->sendMessage("§cYou cannot execute this command.");
			return;
        }
        foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
            if(!$online->isOp()){
                $online->sendPopup("Server restarting in 8 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 7 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 6 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 5 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 4 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 3 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 2 (Transfer to Hub)");
                sleep(1);
                $online->sendPopup("Server restarting in 1 (Transfer to Hub)");
                sleep(2);
                API::transfer($online, "Hub");
            }
        }
	}
}