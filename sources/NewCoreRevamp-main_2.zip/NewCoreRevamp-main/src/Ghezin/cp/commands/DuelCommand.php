<?php

declare(strict_types=1);

namespace Ghezin\cp\commands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use Ghezin\cp\Core;
use Ghezin\cp\duels\DuelInvite;
use Ghezin\cp\Utils;
use Ghezin\cp\forms\{SimpleForm, CustomForm, ModalForm};

class DuelCommand extends PluginCommand
{
    public $from;
    private $plugin;

    public function __construct(Core $plugin)
    {
        parent::__construct("duel", $plugin);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $player, string $commandLabel, array $args)
    {
        if(!$player instanceof Player)
        {
            return;
        }
        if ($player->isTagged()) {
            $player->sendMessage("§cYou cannot use this command while in combat.");
            return;
        }
        $duel = $this->plugin->getDuelHandler()->getDuelFromSpec($player);
        if ($this->plugin->getDuelHandler()->isInDuel($player) or $this->plugin->getDuelHandler()->isInBotDuel($player) or !is_null($duel)) {
            $player->sendMessage("§cYou cannot use this command while in a duel.");
            return;
        }
        if (!isset($args[0])) {
            $player->sendMessage("§cYou must provide a player.");
            return;
        }
        if ($this->plugin->getServer()->getPlayer($args[0]) === null) {
            $player->sendMessage("§cPlayer not found.");
            return;
        }
        $target = $this->plugin->getServer()->getPlayer($args[0]);
        if ($target->getName() == $player->getName()) {
            $player->sendMessage("§cYou cannot duel yourself.");
            return;
        }
        $target = $this->plugin->getServer()->getPlayer($args[0]);
        if ($target->getLevel()->getName() != Core::LOBBY) {
            $player->sendMessage("§cThis player cannot duel at the moment.");
            return;
        }
        if (!isset($args[1])) {
            $player->sendMessage("§cYou must provide a mode. Modes: (nodebuff, gapple, soup, builduhc)");
            return;
        }
        $target = $this->plugin->getServer()->getPlayer($args[0]);
        $mode = $args[1];
        switch ($mode) {
            case "nodebuff":
                $mode = "NoDebuff";
                $player->sendMessage("§aYou sent a " . $mode . " duel request to " . Utils::getPlayerDisplayName($target) . ".");
                $target->sendMessage("§a" . Utils::getPlayerDisplayName($player) . " sent you a " . $mode . " duel request.\n§4Didn't go through? Make sure to close chat and tell them to send a request again!");
                //$this->plugin->getDuelHandler()->addPlayerToQueue($target, "NoDebuff", false);
                $this->requestFormNodebuff($target, $player);
                /*$invite = new DuelInvite($mode, $player->getName(), $target->getName());
                $this->plugin->duelInvites[]=$invite;*/
                $this->from = $player;
                break;
            default:
                $player->sendMessage("§cYou must provide a valid mode.");
                switch ($mode) {
                    case "gapple":
                        $mode = "gapple";
                        $player->sendMessage("§aYou sent a " . $mode . " duel request to " . Utils::getPlayerDisplayName($target) . ".");
                        $target->sendMessage("§a" . Utils::getPlayerDisplayName($player) . " sent you a " . $mode . " duel request.\n§4Didn't go through? Make sure to close chat and tell them to send a request again!");
                        //$this->plugin->getDuelHandler()->addPlayerToQueue($target, "NoDebuff", false);
                        $this->requestFormGapple($target, $player);
                        /*$invite = new DuelInvite($mode, $player->getName(), $target->getName());
                        $this->plugin->duelInvites[]=$invite;*/
                        break;
                    default:
                        $player->sendMessage("§cYou must provide a valid mode.");
                        break;
                }
                switch ($mode) {
                    case "soup":
                        $mode = "soup";
                        $player->sendMessage("§aYou sent a " . $mode . " duel request to " . Utils::getPlayerDisplayName($target) . ".");
                        $target->sendMessage("§a" . Utils::getPlayerDisplayName($player) . " sent you a " . $mode . " duel request.\n§4Didn't go through? Make sure to close chat and tell them to send a request again!");
                        //$this->plugin->getDuelHandler()->addPlayerToQueue($target, "NoDebuff", false);
                        $this->requestFormSoup($target, $player);
                        /*$invite = new DuelInvite($mode, $player->getName(), $target->getName());
                        $this->plugin->duelInvites[]=$invite;*/
                        $this->from = $player;
                        break;
                    default:
                        $player->sendMessage("§cYou must provide a valid mode.");
                        break;
                }

                switch ($mode) {
                    case "builduhc":
                        $mode = "builduhc";
                        $player->sendMessage("§aYou sent a " . $mode . " duel request to " . Utils::getPlayerDisplayName($target) . ".");
                        $target->sendMessage("§a" . Utils::getPlayerDisplayName($player) . " sent you a " . $mode . " duel request.\n§4Didn't go through? Make sure to close chat and tell them to send a request again!");
                        //$this->plugin->getDuelHandler()->addPlayerToQueue($target, "NoDebuff", false);
                        $this->requestFormBuild($target, $player);
                        /*$invite = new DuelInvite($mode, $player->getName(), $target->getName());
                        $this->plugin->duelInvites[]=$invite;*/
                        $this->from = $player;
                        break;
                    default:
                        $player->sendMessage("§cYou must provide a valid mode.");
                        break;
                }
        }
    }

    public
    function requestFormNodebuff(Player $target, Player $player1): void
    {
        $form = new ModalForm(function (Player $target, $data = null): void {
            switch ($data) {

                case "confirm":
                    $this->plugin->getDuelHandler()->addPlayerToQueue($target, "NoDebuff", false);
                    $this->plugin->getDuelHandler()->addPlayerToQueue($this->from, "NoDebuff", false);
                    break;
                case "decline":
                    $playerName = $target->getName();
                    $target->sendMessage("§4 You declined the request.");
                    $this->from->sendMessage("§4$playerName declined the request.");
                    break;
            }
        });

        $whoSentReq = Utils::getPlayerDisplayName($this->from);
        $form->setTitle("§4Duel Request | NoDebuff§r");
        $form->setContent("§7$whoSentReq has sent you a duel request!");
        $form->setButton1("§aConfirm", 0, "confirm");
        $form->setButton2("§cDecline", 0, "decline");

        $target->sendForm($form);
    }

    public
    function requestFormGapple(Player $target, Player $player): void
    {
        $form = new ModalForm(function (Player $target, $data = null): void {
            switch ($data) {
                case "confirm":
                    $this->plugin->getDuelHandler()->addPlayerToQueue($target, "Gapple", false);
                    $this->plugin->getDuelHandler()->addPlayerToQueue($this->from, "Gapple", false);

                    break;
                case "decline":
                    $playerName = $target->getName();
                    $target->sendMessage("§4 You declined the request.");
                    $this->from->sendMessage("§4$playerName declined the request.");
                    break;
            }
        });

        $whoSentReq = Utils::getPlayerDisplayName($target);
        $form->setTitle("§4Duel Request | Gapple§r");
        $form->setContent("§7$whoSentReq has sent you a duel request!");
        $form->setButton1("§aConfirm", 0, "confirm");
        $form->setButton2("§cDecline", 0, "decline");

        $target->sendForm($form);
    }

    public
    function requestFormSoup(Player $target, Player $player): void
    {
        $form = new ModalForm(function (Player $target, $data = null): void {
            switch ($data) {
                case "confirm":
                    $this->plugin->getDuelHandler()->addPlayerToQueue($target, "Soup", false);
                    $this->plugin->getDuelHandler()->addPlayerToQueue($this->from, "Soup", false);

                    break;
                case "decline":
                    $playerName = $target->getName();
                    $target->sendMessage("§4 You declined the request.");
                    $player->sendMessage("§4$playerName declined the request.");
                    break;
            }
        });

        $whoSentReq = Utils::getPlayerDisplayName($target);
        $form->setTitle("§4Duel Request | Soup§r");
        $form->setContent("§7$whoSentReq has sent you a duel request!");
        $form->setButton1("§aConfirm", 0, "confirm");
        $form->setButton2("§cDecline", 0, "decline");

        $target->sendForm($form);
    }

    public
    function requestFormBuild(Player $target, Player $player): void
    {
        $form = new ModalForm(function (Player $target, $data = null): void {
            switch ($data) {
                case "confirm":
                    $this->plugin->getDuelHandler()->addPlayerToQueue($target, "BuildUHC", false);
                    $this->plugin->getDuelHandler()->addPlayerToQueue($this->from, "BuildUHC", false);

                    break;
                case "decline":
                    $playerName = $target->getName();
                    $target->sendMessage("§4 You declined the request.");
                    $player->sendMessage("§4$playerName declined the request.");
                    break;
            }
        });

        $whoSentReq = Utils::getPlayerDisplayName($target);
        $form->setTitle("§4Duel Request | Build UHC§r");
        $form->setContent("§7$whoSentReq has sent you a duel request!");
        $form->setButton1("§aConfirm", 0, "confirm");
        $form->setButton2("§cDecline", 0, "decline");

        $target->sendForm($form);
    }

    }
