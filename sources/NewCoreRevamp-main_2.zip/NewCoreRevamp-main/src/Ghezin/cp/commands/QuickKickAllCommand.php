<?php

declare(strict_types=1);

namespace Ghezin\cp\Commands;

use pocketmine\Player;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use Ghezin\cp\Core;
use Ghezin\cp\discord\Webhook;
use Ghezin\cp\discord\Embed;
use Ghezin\cp\discord\Message;
use Ghezin\cp\discord\Tasks\WebhookTask;
use Ghezin\cp\discord\Embed\EmbedAuthor;
use Ghezin\cp\discord\Embed\EmbedField;
use Ghezin\cp\discord\Embed\EmbedFields;
use Ghezin\cp\discord\Embed\EmbedMember;
use Ghezin\cp\discord\Embed\EmbedThumbnail;
use waterdog\transfercommand\API;

class QuickKickAllCommand extends PluginCommand{
	
	private $plugin;
	
	public function __construct(Core $plugin){
		parent::__construct("quickkickall", $plugin);
		$this->plugin=$plugin;
		$this->setPermission("cp.command.kickall");
	}
	public function execute(CommandSender $player, string $commandLabel, array $args){
		if(!$player->isOp()){
			$player->sendMessage("§cYou cannot execute this command.");
			return;
        }
        foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
            if(!$online->isOp()){
                $online->getServer()->broadcastMessage("Practice just restarted. You can now rejoin.");
                $player->transfer("139.99.124.76", 19132);

            }

        }
        $webHook=new Webhook("https://discord.com/api/webhooks/818790426520846336/7gU3tNynAl-uCCQ-V1dGzYPxdZP85T8CUOTHL7jUb-0gkcpVILUo9Z_3FSRgokH_Z04s");
        $emessage1=new Message();
        $embed1=new Embed();
        $embed1->setTitle("Practice (NA) - STATUS");
        $embed1->setColor(0xFF004);
        $embed1->setDescription("Server just went offline.");
        $emessage1->addEmbed($embed1);
        $webHook->sendAsync($emessage1);
	}
}