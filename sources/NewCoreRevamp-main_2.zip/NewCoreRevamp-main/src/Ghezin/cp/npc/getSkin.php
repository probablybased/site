<?php


namespace HippoBaguette\NPC;

use pocketmine\entity\Skin;
use pocketmine\plugin\PluginBase;

@mkdir($this->getDataFolder());

class getSkin
{
    public function __construct()
    {
        @mkdir($this->getDataFolder());
        $this->saveResource("MyConfig.yml");
        $this->myConfig = new Config($this->getDataFolder() . "MyConfig.yml", Config::YAML);
    }

    public function generateSkin(){
        $this->saveResource("npcskin1.png");

        $path = 'your/path/to/skin.png';
        $img = @imagecreatefrompng($path);
        $bytes = '';
        $l = (int) @getimagesize($path)[1];

        for ($y = 0; $y < $l; $y++) {
            for ($x = 0; $x < 64; $x++) {
                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }

        @imagedestroy($img);

        return $bytes;
    }

}