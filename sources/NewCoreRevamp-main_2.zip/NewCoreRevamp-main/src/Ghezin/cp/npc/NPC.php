<?php


namespace HippoBaguette\NPC;


use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\nbt\tag\CompoundTag;

class NPC extends Human
{
    public $name;
    public function __construct(Level $level, CompoundTag $nbt, String $name, Position $position)
    {
        parent::__construct($level, $nbt);
        $this->name = $name;
        $this->setPosition($position);
    }
    public function getName(): string
    {
        return $this->name;
    }
    public function setNPCSkin(): void
    {
        $getSkin = new getSkin();
        $bytes = $getSkin->generateSkin();
        $this->setSkin(new Skin("Standard_CustomSlim", $bytes)); //Standard_CustomSlim for alex
        $this->sendSkin();
    }
}