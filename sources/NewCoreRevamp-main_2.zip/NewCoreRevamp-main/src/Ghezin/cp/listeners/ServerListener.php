<?php

declare(strict_types=1);

namespace Ghezin\cp\listeners;

use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\event\plugin\PluginDisableEvent;
use Ghezin\cp\Core;
use Ghezin\cp\tasks\onetime\RestartTask;
use Ghezin\cp\discord\Webhook;
use Ghezin\cp\discord\Embed;
use Ghezin\cp\discord\Message;
use Ghezin\cp\discord\Tasks\WebhookTask;
use Ghezin\cp\discord\Embed\EmbedAuthor;
use Ghezin\cp\discord\Embed\EmbedField;
use Ghezin\cp\discord\Embed\EmbedFields;
use Ghezin\cp\discord\Embed\EmbedMember;
use Ghezin\cp\discord\Embed\EmbedThumbnail;
use pocketmine\event\player\PlayerChatEvent;

class ServerListener implements Listener{
	
	public $plugin;
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}
	/**
	* @priority HIGHEST
	*/
	public function onQuery(QueryRegenerateEvent $event){
		//$event->setMaxPlayerCount(count($this->plugin->getServer()->getOnlinePlayers()) + 30);
	}
	/**
	* @priority HIGHEST
	*/
	public function onPluginDisable(PluginDisableEvent $event){
		$plugin=$event->getPlugin();
		if($plugin->getName()=="AstralPvP"){
			foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
				if($this->plugin->getDuelHandler()->isInDuel($player)){
					$duel=$this->plugin->getDuelHandler()->getDuel($player);
					$duel->endDuelPrematurely(true);
				}
				if($this->plugin->getDuelHandler()->isInPartyDuel($player)){
					$pduel=$this->plugin->getDuelHandler()->getPartyDuel($player);
					$pduel->endDuelPrematurely(true);
				}
			}
		}
	}
/**
* @priority LOW
* @ignoreCancelled false
*/
    public function onHit(EntityDamageEventByEntity $event, Player $player) {
        if ($event->isCancelled()) return;
        $player - $event->getPlayer();
        $player->sendMessage("disabled!!!!");
    }

    /**
     * @priority LOW
     * @ignoreCancelled false
     */
    public function onHit2(EntityDamageEvent $event, Player $player) {
        if ($event->isCancelled()) return;
        $player - $event->getPlayer();
        $player->sendMessage("disabled!!!!");
    }
    /**
     * @priority HIGHEST
     */
    public function onChat(PlayerChatEvent $event){

        $player = $event->getPlayer();
        $name = $player->getName();
        $msgtext = $event->getMessage();

        $webHook=new Webhook("https://discord.com/api/webhooks/818784049908547635/EVVF9ZP3hHS4j-_ANzLYYBQno-3xZpzmFn8kbJRpjIpUF1f85xai_AnGadCUrDe_AltR");
        $emessage=new Message();
        $embed=new Embed();
        $embed->setTitle("Practice (NA)");
        $embed->setColor(0x00FF00);
        $embed->setDescription("**$name**: $msgtext");
        $emessage->addEmbed($embed);
        $webHook->sendAsync($emessage);

    }

}