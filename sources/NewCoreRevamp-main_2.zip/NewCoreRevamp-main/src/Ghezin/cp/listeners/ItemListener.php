<?php

declare(strict_types=1);

namespace Ghezin\cp\listeners;

use Ghezin\cp\bots\Bot;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use Ghezin\cp\forms\{SimpleForm, CustomForm, ModalForm};
use Ghezin\cp\duels\groups\{DuelGroup, PartyDuelGroup};
use Ghezin\cp\duels\groups\BotDuelGroup;
use Ghezin\cp\duels\groups\QueuedPlayer;
use Ghezin\cp\duels\groups\MatchedGroup;
use Ghezin\cp\Core;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ListTag;
use Ghezin\cp\Kits;
use Ghezin\cp\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class ItemListener implements Listener{
	
	public $plugin;
	
	public $targetDuel=[];
	
	private $formCd=[];
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}

    public function warpHub(Player $player):void{
        $x = 38;
        $y = 9;
        $z = -54;
        $lobby = $this->plugin->getServer()->getLevelByName("lobby");
        //new Vector3($x, $y, $z, 0, 0, $lobby)
        $player->teleport(new Vector3($x, $y, $z), 0,0);
        //$this->setItems($player);
    }

	public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        //$this->spectateForm($player);
        $item = $player->getInventory()->getItemInHand();
        if($item->getId() == 364)
        {
            return;
        }
        if ($item->getCustomName() == " §l§dDuels§r ") {
            $event->setCancelled();
            if ($player->isInParty()) {
                $player->sendMessage("§cDisabled in a party!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->duelForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->duelForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§8» §7Join Ranked Duels §8«") {
            $event->setCancelled();
            if ($player->isInParty()) {
                $player->sendMessage("§cDisabled in a party!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->rankedForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->rankedForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§8» §7Join Unranked Duels §8«") {
            $event->setCancelled();
            if ($player->isInParty()) {
                $player->sendMessage("§cDisabled in a party!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->unrankedForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->unrankedForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§8» §7Spectate Duels §8«") {
            $event->setCancelled();
            if ($player->isInParty()) {
                $player->sendMessage("§cDisabled in a party!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->spectateForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->spectateForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§8» §7Join Bot Duels §8«") {
            $event->setCancelled();
            if ($player->isInParty()) {
                $player->sendMessage("§cDisabled in a party!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->botDuelForm($player);
                //$player->sendMessage("§cCurrently Disabled!");
                //$player->sendMessage("§aBot duels need vast improvement, please stay updated with it's progress in our discord.");
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->botDuelForm($player);
                    //$player->sendMessage("§cCurrently Disabled!");
                    //$player->sendMessage("§aBot duels need vast improvement, please stay updated with it's progress in our discord.");
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§8» §7Join FFA §8«") {
            $event->setCancelled();
            if ($player->isInParty()) {
                //if(!$player->getParty()->isLeader($player)){
                $player->sendMessage("§cDisabled in a party!");
                return;
                //}
            }
            if ($this->plugin->getDuelHandler()->isPlayerInQueue($player)) {
                $player->sendMessage("§cYou cannot access this while in queue!");
                return;
            }
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->warpForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->warpForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§e§lLeaderboards §r§7(Click)§r") {
            $event->setCancelled();
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->leaderboardsForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->leaderboardsForm($player);
                    return;
                }
            }
        }
        if ($item->getCustomName() == "§r§5» §dPlay Games §5«") {
            $event->setCancelled();
            $cooldown = 1;
            if (!isset($this->formCd[$player->getName()])) {
                $this->formCd[$player->getName()] = time();
                $this->gamesForm($player);
            } else {
                if ($cooldown > time() - $this->formCd[$player->getName()]) {
                    $time = time() - $this->formCd[$player->getName()];
                } else {
                    $this->formCd[$player->getName()] = time();
                    $this->gamesForm($player);
                    return;
                }
                if ($item->getCustomName() == "§r§8» §r§4Back to spawn §8«") {
                    $event->setCancelled();
                    $cooldown = 1;
                    if(!isset($this->formCd[$player->getName()])){
                        $this->formCd[$player->getName()]=time();
                        $this->warpHub($player);

                    }else{
                        if($cooldown > time() - $this->formCd[$player->getName()]){
                            $time=time() - $this->formCd[$player->getName()];
                        }else{
                            $this->formCd[$player->getName()]=time();
                            $this->warpHub($player);
                            return;
                        }
                    }
                }



                    $block = $event->getBlock();
                    $id = $block->getId();
                    if ($id == "131") {
                        $event->setCancelled();
                        if ($this->plugin->getDuelHandler()->isPlayerInQueue($player)) {
                            $player->sendMessage("§cYou cannot access this while in queue!");
                            return;
                        }
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->sendChangelogforlobby($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->sendChangelogforlobby($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§e§lParty §r§7(Click)§r") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->plugin->getForms()->partyForm($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->plugin->getForms()->partyForm($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§e§lCosmetics §r§7(Click)§r") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->cosmeticsForm($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->cosmeticsForm($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§8» §7Your Profile §8«") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->playerPortalForm($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->playerPortalForm($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§e§lEvents §r§7(Click)§r") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $player->sendMessage("§r§cCurrently Disabled!");
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $player->sendMessage("§r§cCurrently Disabled!");
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§bLobby") {
                        $event->setCancelled();
                        $player->sendTo(0, true);
                        return;
                    }
                    if ($item->getCustomName() == "§r§cLeave Duel") {
                        $event->setCancelled();
                        $duel = $this->plugin->getDuelHandler()->getDuelFromSpec($player);
                        $pduel = $this->plugin->getDuelHandler()->getPartyDuelFromSpec($player);
                        if (!is_null($duel)) $duel->removeSpectator($player, true);
                        if (!is_null($pduel)) $pduel->removeSpectator($player, true);
                        return;
                    }
                    /*if($item->getCustomName()=="§r§bSelect Combo Kit"){
                        $event->setCancelled();
                        Kits::sendKit($player, "combo");
                    }
                    if($item->getCustomName()=="§r§bSelect NoDebuff Kit"){
                        $event->setCancelled();
                        Kits::sendKit($player, "nodebuff");
                    }
                    if($item->getCustomName()=="§r§bSelect Gapple Kit"){
                        $event->setCancelled();
                        Kits::sendKit($player, "gapple");
                    }*/
                    if ($item->getCustomName() == "§r§dTeleport To Arenas") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->plugin->getStaffUtils()->teleportForm($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->plugin->getStaffUtils()->teleportForm($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§dStaff Mode") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->plugin->getStaffUtils()->staffPortalForm($player);
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->plugin->getStaffUtils()->staffPortalForm($player);
                                return;
                            }
                        }
                    }
                    if ($item->getCustomName() == "§r§cLeave §dStaff Mode") {
                        $event->setCancelled();
                        $cooldown = 1;
                        if (!isset($this->formCd[$player->getName()])) {
                            $this->formCd[$player->getName()] = time();
                            $this->plugin->getServer()->dispatchCommand($player, "staff");
                        } else {
                            if ($cooldown > time() - $this->formCd[$player->getName()]) {
                                $time = time() - $this->formCd[$player->getName()];
                            } else {
                                $this->formCd[$player->getName()] = time();
                                $this->plugin->getServer()->dispatchCommand($player, "staff");
                                return;
                            }
                        }
                    }
                }
            }
        }



	public function sendChangelogforlobby(Player $player){
		$form=new SimpleForm(function(Player $player, $data=null){
		});
		$form->setTitle("§a§lPractice");
		$form->setContent("§7Changelog #1\n\n§r"."\n- Better KB (NoDebuff)!\n- Party's are fully functional now, you can start duels/scrims with them!\n- Edited Bot KB!\n- Removed /duel!\n- Removed floating leaderboards instead added an item in hub for it!\n- Better Scoreboard!\n- Removed Unranked/Ranked items instead added them in one single ui with a new feature spectator!"."\n\n§7Have any concerns or idea's that you want implemented/removed? Join our discord at §a".Core::DISCORD."§7.§r");
		$form->addButton("Confirm");
		$player->sendForm($form);
	}
	public function profileTap2(BlockPlaceEvent $event){
		$block=$event->getBlock();
		$id=$block->getId();
		$meta=$block->getDamage();
		if($id==144 and $meta==3){
			if($block->getCustomName()=="§r§bProfile"){
				$event->setCancelled();
				}else{
					return;
			}
		}
	}
	public function cosmeticsForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			$color=$data[0];
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0:
				$color="default";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 1:
				$color="pink";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 2:
				$color="purple";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 3:
				$color="blue";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 4:
				$color="cyan";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 5:
				$color="green";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 6:
				$color="yellow";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 7:
				$color="orange";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 8:
				$color="white";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 9:
				$color="grey";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 10:
				$color="black";
				if(Utils::potSplashColor($player)!=$color){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "pot-splash-color", $color);
						$player->sendMessage("§aYour pot splash color is now ".$color.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
			}
			switch($data[1]){
				case 0:
				$multiplier="off";
				if(Utils::particleMod($player)!=$multiplier){
					Utils::setPlayerData($player, "particle-mod", $multiplier);
					$player->sendMessage("§aYour particle mod multiplier is now set to ".$multiplier.".");
				}
				break;
				case 1:
				$multiplier="x1";
				if(Utils::particleMod($player)!=$multiplier){
					Utils::setPlayerData($player, "particle-mod", $multiplier);
					$player->sendMessage("§aYour particle mod multiplier is now set to ".$multiplier.".");
				}
				break;
				case 2:
				$multiplier="x2";
				if(Utils::particleMod($player)!=$multiplier){
					Utils::setPlayerData($player, "particle-mod", $multiplier);
					$player->sendMessage("§aYour particle mod multiplier is now set to ".$multiplier.".");
				}
				break;
				case 3:
				$multiplier="x4";
				if(Utils::particleMod($player)!=$multiplier){
					Utils::setPlayerData($player, "particle-mod", $multiplier);
					$player->sendMessage("§aYour particle mod multiplier is now set to ".$multiplier.".");
				}
				break;
				/*case 4:
				$multiplier="x8";
				if(Utils::particleMod($player)!=$multiplier){
					Utils::setPlayerData($player, "particle-mod", $multiplier);
					$player->sendMessage("§aYour particle mod multiplier is now set to ".$multiplier.".");
				}
				break;*/
			}
			/*switch($data[2]){
				case 0:
				$pot="default";
				if(Utils::preferredPot($player)!=$pot){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "preferred-pot", $pot);
						$player->sendMessage("§aYour preferred pot is now set to ".$pot.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
				case 1:
				$pot="fast";
				if(Utils::preferredPot($player)!=$pot){
					if($player->isOp() or $player->isElite() or $player->isPremium() or $player->isStaff()){
						Utils::setPlayerData($player, "preferred-pot", $pot);
						$player->sendMessage("§aYour preferred  pot is now set to ".$pot.".");
					}else{
						$player->sendMessage("§cNo permissions to use this cosmetic!");
					}
				}
				break;
			}*/
		});
		$colors=["§cDefault","§dPink","§5Purple","§1Blue","§bCyan","§aGreen","§eYellow","§6Orange","§fWhite","§7Grey","§0Black"];
		$multipliers=["Off","x1","x2","x4"];
		$pots=["Default", "Fast"];
		$preferredpot=Utils::preferredPot($player);
		$potsplashcolor=Utils::potSplashColor($player);
		$form->setTitle("§7Cosmetics");
		/*$def1=-1;
		if(Utils::potSplashColor($player)=="default") $def1=0;
		if(Utils::potSplashColor($player)=="pink") $def1=1;
		if(Utils::potSplashColor($player)=="purple") $def1=2;
		if(Utils::potSplashColor($player)=="blue") $def1=3;
		if(Utils::potSplashColor($player)=="cyan") $def1=4;
		if(Utils::potSplashColor($player)=="green") $def1=5;
		if(Utils::potSplashColor($player)=="yellow") $def1=6;
		if(Utils::potSplashColor($player)=="orange") $def1=7;
		if(Utils::potSplashColor($player)=="white") $def1=8;
		if(Utils::potSplashColor($player)=="grey") $def1=9;
		if(Utils::potSplashColor($player)=="black") $def1=10;
		$form->addStepSlider("PotSplash-Color", $colors, $def1, null);//data0*/
		switch($potsplashcolor){
			case 0:
			$form->addDropdown("Potion Splash Color", $colors, 0);
			break;
			case 1:
			$form->addDropdown("Potion Splash Color", $colors, 1);
			break;
			case 2:
			$form->addDropdown("Potion Splash Color", $colors, 2);
			break;
			case 3:
			$form->addDropdown("Potion Splash Color", $colors, 3);
			break;
			case 4:
			$form->addDropdown("Potion Splash Color", $colors, 4);
			break;
			case 5:
			$form->addDropdown("Potion Splash Color", $colors, 5);
			break;
			case 6:
			$form->addDropdown("Potion Splash Color", $colors, 6);
			break;
			case 7:
			$form->addDropdown("Potion Splash Color", $colors, 7);
			break;
			case 8:
			$form->addDropdown("Potion Splash Color", $colors, 8);
			break;
			case 9:
			$form->addDropdown("Potion Splash Color", $colors, 9);
			break;
			case 10:
			$form->addDropdown("Potion Splash Color", $colors, 10);
			break;
		}
		/*$def2=-1;
		if(Utils::particleMod($player)=="off") $def2=0;
		if(Utils::particleMod($player)=="x1") $def2=1;
		if(Utils::particleMod($player)=="x2") $def2=2;
		if(Utils::particleMod($player)=="x4") $def2=3;
		$form->addStepSlider("Crit-Particles", $multipliers, $def2, null);//data0*/
		
		$particlemod = Utils::particleMod($player);
		
		switch($particlemod){
			case 0:
			$form->addDropdown("Crit Particles", $multipliers, 0);
			break;
			case 1:
			$form->addDropdown("Crit Particles", $multipliers, 1);
			break;
			case 2:
			$form->addDropdown("Crit Particles", $multipliers, 2);
			break;
			case 3:
			$form->addDropdown("Crit Particles", $multipliers, 3);
			break;
		}
		/*switch($preferredpot){
			case "default":
			$form->addDropdown("Pick your preferred potion", $pots, 0);
			break;
			case "fast":
			$form->addDropdown("Pick your preferred potion", $pots, 1);
			break;
			default:
			$form->addDropdown("Pick your preferred potion", $pots, 0);
			break;
		}*/
		$player->sendForm($form);
	}
	public function playerPortalForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "stats":
				$this->statsForm($player);
				break;
				case "friends":
				$this->friendsForm($player);
				break;
				case "locker":
				$this->lockerForm($player);
				break;
				case "settings":
				$this->settingsForm($player);
				break;
				case "capeCMD":
				$this->plugin->getServer()->dispatchCommand($player, "cape");
				//$player->sendMessage("§cError:§7 Use /cape for now§7!§r");
				//$this->capesForm($player);
				break;
				case "cosmetics":
				$this->cosmeticsForm($player);
				break;
				default:
				return;
			}
		});
		$form->setTitle("§7Profile");
		//$form->addButton("§7Manage Tag-Slots", -1, "", "mytagslots");
		$form->addButton("§7Stats", -1, "", "stats");
		$form->addButton("§7Capes", -1, "", "capeCMD");
		$form->addButton("§7Cosmetics", -1, "", "cosmetics");
		//$form->addButton("Friends", -1, "", "friends");
		//$form->addButton("Locker", -1, "", "locker");
		$form->addButton("§7Settings", -1, "", "settings");
		//$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	public function statsForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->playerPortalForm($player);
				break;
			}
		});
		$elo=$this->plugin->getDatabaseHandler()->getRankedElo($player->getName());
		$wins=$this->plugin->getDatabaseHandler()->getWins($player->getName());
		$losses=$this->plugin->getDatabaseHandler()->getLosses($player->getName());
		$ffaelo=$this->plugin->getDatabaseHandler()->getElo($player->getName());
		$kills=$this->plugin->getDatabaseHandler()->getKills($player->getName());
		$deaths=$this->plugin->getDatabaseHandler()->getDeaths($player->getName());
		$kdr=$this->plugin->getDatabaseHandler()->getKdr($player->getName());
		$killstreak=$this->plugin->getDatabaseHandler()->getKillstreak($player->getName());
		$bestkillstreak=$this->plugin->getDatabaseHandler()->getBestKillstreak($player->getName());
		$form->setTitle("§7Stats");
		$form->setContent("§7Elo: §f".$elo."\n\n§7Kills: §f".$kills."\n§7Deaths: §f".$deaths."\n§7KDR: §f".$kdr."\n§7Killstreak: §f".$killstreak."\n§7Best KillStreak: §f".$bestkillstreak);
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	public function gamesForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "duels":
				$this->duelForm($player);
				break;
				case "ffa":
				$this->warpForm($player);
				break;
				case "botduels":
				$this->botDuelForm($player);
				break;
                case "custombot":
                    $this->customBotForm($player);
                    break;
				case "profile":
				$this->playerPortalForm($player);
				break;
				case "staff":
				$this->plugin->getServer()->dispatchCommand($player, "staff");
				break;
				case "exit":
				break;
				default:
				break;
			}
		});
		$form->setTitle("§l§5Play Games");
		$form->addButton("§dPlay Duels", -1, "", "duels");
		$form->addButton("§dPlay FFA", -1, "", "ffa");
		$form->addButton("§dPlay Bot Duels", -1, "", "botduels");
        $form->addButton("§dCustom Bot Duel", -1, "", "custombot");
		$form->addButton("§dCheck Your Profile", -1, "", "profile");
		if($player->isOp() or $player->isStaff()){
		   $form->addButton("§l§4Staff Mode", -1, "", "staff");
		}
		$form->addButton("§cExit", -1, "", "exit");
		$player->sendForm($form);
	}
	public function friendsForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->playerPortalForm($player);
				break;
				case "friends":
				$this->viewFriendsForm($player);
				break;
			}
		});
		$friends=$this->plugin->getDatabaseHandler()->getFriendsCount($player->getName());
		$form->setTitle("Friends");
		$form->addButton("Friends [".$friends."]", -1, "", "friends");
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	public function lockerForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "capes":
				$this->capesForm($player);
				break;
				case "exit":
				$this->playerPortalForm($player);
				break;
			}
		});
		$form->setTitle("§7Locker");
		$form->addButton("§7Capes", -1, "", "capes");
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	
	public function capesForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "vasar":
				if($player->hasCape()){
					$oldSkin=$player->getSkin();
					$skin=new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), "", $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
					$player->setSkin($skin);
					$player->sendSkin();
					$player->setHasCape(false);
				}else{
					$cape=Utils::createImage("vasar");
					$skin=new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $cape, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
					$player->setSkin($skin);
					$player->sendSkin();
					$player->setHasCape(true);
				}
				break;
				case "exit":
				$this->playerPortalForm($player);
				break;
			}
		});
		$form->setTitle("§7Capes");
		$form->addButton("§7PotPvP", -1, "", "vasar");
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	/*public function settingsForm(Player $player):void{
		$form = new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0:
				if(Utils::isScoreboardEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "scoreboard", false);
				//$player->sendMessage("§cScoreBoard Disabled!");
				$this->plugin->getScoreboardHandler()->removeScoreboard($player);
				break;
				case 1:
				if(Utils::isScoreboardEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "scoreboard", true);
				$this->plugin->getScoreboardHandler()->sendMainScoreboard($player, "Practice");
				//$player->sendMessage("§aScoreboard Enabled!");
				return;
				break;
			}
			switch($data[1]){
				case 0:
				if(Utils::isAutoRekitEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "auto-rekit", false);
				//$player->sendMessage("§cAuto-Rekit Disabled!");
				break;
				case 1:
				if(Utils::isAutoRekitEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "auto-rekit", true);
				//$player->sendMessage("§aAuto-Rekit Enabled!");
				return;
				break;
			}
			switch($data[2]){
				case 0:
				if(Utils::isAutoSprintEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "auto-sprint", false);
				//$player->sendMessage("§cAuto-Sprint Disabled!");
				break;
				case 1:
				if(Utils::isAutoSprintEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "auto-sprint", true);
				//$player->sendMessage("§aAuto-Sprint Enabled!");
				return;
				break;
			}
			switch($data[3]){
				case 0:
				if(Utils::isCpsCounterEnabled($player)==false){
					return;
				}else{
				Utils::setPlayerData($player, "cps-counter", false);
			    }
				//$player->sendMessage("§cCPS Counter Disabled!");
				break;
				case 1:
				if(Utils::isCpsCounterEnabled($player)==true){
					return;
				}else{
				Utils::setPlayerData($player, "cps-counter", true);
			    }
				//$player->sendMessage("§aCPS Counter Enabled!");
				return;
				break;
			}

		});
		$scoreboard = Utils::isShowInLeaderboardsEnabled($player);
		$autorequeue = Utils::isAutoRekitEnabled($player);
		$autosprint = Utils::isAutoSprintEnabled($player);
		$cps = Utils::isCpsCounterEnabled($player);
		$toggle = ["§cDisabled","§aEnabled"];

		switch($scoreboard){
			case 0:
			$form->addDropdown("§8Scoreboard", $toggle, 0);
			break;
			case 1:
			$form->addDropdown("§8Scoreboard", $toggle, 1);
			break;
		}
		switch($autorequeue){
			case 0:
			$form->addDropdown("§8Auto Requeue", $toggle, 0);
			break;
			case 1:
			$form->addDropdown("§8Auto Requeue", $toggle, 1);
			break;
		}
		switch($autosprint){
			case 0:
			$form->addDropdown("§8Auto Sprint", $toggle, 0);
			break;
			case 1:
			$form->addDropdown("§8Auto Sprint", $toggle, 1);
			break;
		}
		switch($cps){
			case 0:
			$form->addDropdown("§8CPS Counter", $toggle, 0);
			break;
			case 1:
			$form->addDropdown("§8CPS Counter", $toggle, 1);
			break;
		}

		$player->sendForm($form);
		if(Utils::isShowInLeaderboardsEnabled($player)==true){
			$form->addDropdown("§aEnabled", true, null);
		}else{
			$form->addDropdown("§cDisabled", false, null);
		}
	}*/
	public function settingsForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "pot":
				$this->potFeedbackForm($player);
				break;
				case "leaderboards":
				$this->showInLdbrdsForm($player);
				break;
				case "scoreboard":
				$this->scoreboardForm($player);
				break;
				case "requeue":
				$this->requeueForm($player);
				break;
				case "rekit":
				$this->rekitForm($player);
				break;
				case "sprint":
				$this->sprintForm($player);
				break;
				case "cps":
				$this->cpsForm($player);
				break;
				case "swingsounds":
				$this->swingSoundsForm($player);
				break;
				case "exit":
				$this->playerPortalForm($player);
				break;
				case "locker":
				$this->lockerForm($player);
				break;
				case "cosmetics":
				$this->cosmeticsForm($player);
				break;
			}
		});

		if(Utils::isScoreboardEnabled($player) == false){
			$st = "§cDisabled§r";
		}elseif(Utils::isScoreboardEnabled($player) == true){
			$st = "§aEnabled§r";
		}

		if(Utils::isCpsCounterEnabled($player) == false){
			$ct = "§cDisabled§r";
		}elseif(Utils::isCpsCounterEnabled($player) == true){
			$ct = "§aEnabled§r";
		}

		if(Utils::isAutoRequeueEnabled($player) == false){
			$arq = "§cDisabled§r";
		}elseif(Utils::isAutoRequeueEnabled($player) == true){
			$arq = "§aEnabled§r";
		}

		if(Utils::isAutoRekitEnabled($player) == false){
			$ark = "§cDisabled§r";
		}elseif(Utils::isAutoRekitEnabled($player) == true){
			$ark = "§aEnabled§r";
		}

		if(Utils::isAutoSprintEnabled($player) == false){
			$as = "§cDisabled§r";
		}elseif(Utils::isAutoSprintEnabled($player) == true){
			$as = "§aEnabled§r";
		}

		$form->setTitle("§7Settings");
		//$form->addButton("Pot Feedback\n§bFeedback upon throwing pots", -1, "", "pot");
		//$form->addButton("Show In Leaderboards\n§bYour visibility in leaderboards", -1, "", "leaderboards");
		$form->addButton("§8Scoreboard\n§7Status: $st", -1, "", "scoreboard");
		$form->addButton("§8CPS Counter\n§7Status: $ct", -1, "", "cps");
		$form->addButton("§8Auto ReQueue\n§7Status: $arq", -1, "", "requeue");
		$form->addButton("§8Auto Rekit\n§7Status: $ark", -1, "", "rekit");
		$form->addButton("§8Auto Sprint\n§7Status: $as", -1, "", "sprint");
		//$form->addButton("§8Cosmetics", -1, "", "cosmetics");
		//$form->addButton("§7CPS", -1, "", "cps");
		//$form->addButton("§7Locker", -1, "", "locker");
		//$form->addButton("Swing & Hit Sounds\n§bDisables PVP sounds", -1, "", "swingsounds");
		//$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}
	public function potFeedbackForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isPotFeedbackEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "pot-feedback", false);
				$player->sendMessage("§aYou will no longer receive feedback on your pots.");
				break;
				case 1://on
				if(Utils::isPotFeedbackEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "pot-feedback", true);
				$player->sendMessage("§aYou will now receive feedback on your pots as they are thrown.");
				return;
				break;
			}
		});
		$form->setTitle("Pot Feedback");
		if(Utils::isPotFeedbackEnabled($player)==true){
			$form->addToggle("Enabled", true, null);//data[0]
		}else{
			$form->addToggle("Disabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function showInLdbrdsForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isShowInLeaderboardsEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "show-in-leaderboards", false);
				$player->sendMessage("§aYou will no longer be shown in the leaderboards.");
				break;
				case 1://on
				if(Utils::isShowInLeaderboardsEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "show-in-leaderboards", true);
				$player->sendMessage("§aYou will now be shown in the leaderboards.");
				return;
				break;
			}
		});
		$form->setTitle("Show In Leaderboards");
		if(Utils::isShowInLeaderboardsEnabled($player)==true){
			$form->addToggle("Enabled", true, null);//data[0]
		}else{
			$form->addToggle("Disabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function scoreboardForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isScoreboardEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "scoreboard", false);
				$player->sendMessage("§cScoreBoard Disabled!");
				$this->plugin->getScoreboardHandler()->removeScoreboard($player);
				break;
				case 1://on
				if(Utils::isScoreboardEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "scoreboard", true);
				$this->plugin->getScoreboardHandler()->sendMainScoreboard($player, "Practice");
				$player->sendMessage("§aScoreboard Enabled!");
				return;
				break;
			}
		});
		$form->setTitle("§7Scoreboard");

		if(Utils::isScoreboardEnabled($player)==true){
			$form->addToggle("§aEnabled", true, null);//data[0]
		}else{
			$form->addToggle("§cDisabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function requeueForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isAutoRequeueEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "auto-requeue", false);
				$player->sendMessage("§aYou will no longer be automatically queued after a win.");
				break;
				case 1://on
				if(Utils::isAutoRequeueEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "auto-requeue", true);
				$player->sendMessage("§aYou will now be automatically queued after a win.");
				return;
				break;
			}
		});
		$form->setTitle("Auto Re-queue");
		if(Utils::isAutoRequeueEnabled($player)==true){
			$form->addToggle("Enabled", true, null);//data[0]
		}else{
			$form->addToggle("Disabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function rekitForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isAutoRekitEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "auto-rekit", false);
				$player->sendMessage("§cAuto-Rekit Disabled!");
				break;
				case 1://on
				if(Utils::isAutoRekitEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "auto-rekit", true);
				$player->sendMessage("§aAuto-Rekit Enabled!");
				return;
				break;
			}
		});
		$form->setTitle("§7Auto-Rekit");
		if(Utils::isAutoRekitEnabled($player)==true){
			$form->addToggle("§aEnabled", true, null);//data[0]
		}else{
			$form->addToggle("§cDisabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function sprintForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isAutoSprintEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "auto-sprint", false);
				$player->sendMessage("§cAuto-Sprint Disabled!");
				break;
				case 1://on
				if(Utils::isAutoSprintEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "auto-sprint", true);
				$player->sendMessage("§aAuto-Sprint Enabled!");
				return;
				break;
			}
		});
		$form->setTitle("§7Auto-Sprint");
		if(Utils::isAutoSprintEnabled($player)==true){
			$form->addToggle("§aEnabled", true, null);//data[0]
		}else{
			$form->addToggle("§cDisabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function cpsForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isCpsCounterEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "cps-counter", false);
				$player->sendMessage("§cCPS Counter Disabled!");
				break;
				case 1://on
				if(Utils::isCpsCounterEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "cps-counter", true);
				$player->sendMessage("§aCPS Counter Enabled!");
				return;
				break;
			}
		});
		$form->setTitle("§7CPS");
		if(Utils::isCpsCounterEnabled($player)==true){
			$form->addToggle("§aEnabled", true, null);//data[0]
		}else{
			$form->addToggle("§cDisabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function swingSoundsForm(Player $player):void{
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			switch($data[0]){
				case 0://off
				if(Utils::isSwingSoundEnabled($player)==false){
					return;
				}
				Utils::setPlayerData($player, "swing-sounds", false);
				$player->sendMessage("§aYou will no longer hear swing or hit sounds.");
				break;
				case 1://on
				if(Utils::isSwingSoundEnabled($player)==true){
					return;
				}
				Utils::setPlayerData($player, "swing-sounds", true);
				$player->sendMessage("§aYou will now hear swing and hit sounds.");
				return;
				break;
			}
		});
		$form->setTitle("Swing & Hit Sounds");
		if(Utils::isSwingSoundEnabled($player)==true){
			$form->addToggle("Enabled", true, null);//data[0]
		}else{
			$form->addToggle("Disabled", false, null);//data[0]
		}
		$player->sendForm($form);
	}
	public function leaderboardsForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "kills":
				$this->topKillsForm($player);
				break;
				case "deaths":
				$this->topDeathsForm($player);
				break;
				case "kdr":
				$this->topKdrForm($player);
				break;
				case "ks":
				$this->topKsForm($player);
				break;
				case "elo":
				$this->topEloForm($player);
				break;
			}
		});
		$form->setTitle("§7Leaderboards");
		$form->addButton("§7Top Kills", -1, "", "kills");
		$form->addButton("§7Top Deaths", -1, "", "deaths");
		$form->addButton("§7Top KDR", -1, "", "kdr");
		$form->addButton("§7Top Killstreak", -1, "", "ks");
		$form->addButton("§7Top Elo", -1, "", "elo");
		$player->sendForm($form);
	}
	public function topKillsForm(Player $player):void{
		$form=new SimpleForm(function (Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->leaderboardsForm($player);
				break;
			}
		});
		$form->setTitle("§7Top Kills");
		$query=$this->plugin->main->query("SELECT * FROM essentialstats ORDER BY kills DESC LIMIT 10;");
		while($resultArr=$query->fetchArray(SQLITE3_ASSOC)){
			$players=$resultArr['player'];
			$val=$this->plugin->getDatabaseHandler()->getTopKills($players);
			if(Utils::isShowInLeaderboardsEnabled($players)==true){
				$form->addButton("§2".$players."\n§c".$val." §7Kill(s)");
			}
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function topDeathsForm(Player $player):void{
		$form=new SimpleForm(function (Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->leaderboardsForm($player);
				break;
			}
		});
		$form->setTitle("§7Top Deaths");
		$query=$this->plugin->main->query("SELECT * FROM essentialstats ORDER BY deaths DESC LIMIT 10;");
		while($resultArr=$query->fetchArray(SQLITE3_ASSOC)){
			$players=$resultArr['player'];
			$val=$this->plugin->getDatabaseHandler()->getTopDeaths($players);
			if(Utils::isShowInLeaderboardsEnabled($players)==true){
				$form->addButton("§2".$players."\n§c".$val." §7Death(s)");
			}
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function topKdrForm(Player $player):void{
		$form=new SimpleForm(function (Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->leaderboardsForm($player);
				break;
			}
		});
		$form->setTitle("§7Top KDR");
		$query=$this->plugin->main->query("SELECT * FROM essentialstats ORDER BY kdr DESC LIMIT 10;");
		while($resultArr=$query->fetchArray(SQLITE3_ASSOC)){
			$players=$resultArr['player'];
			$val=$this->plugin->getDatabaseHandler()->getTopKdr($players);
			if(Utils::isShowInLeaderboardsEnabled($players)==true){
				$form->addButton("§2".$players."\n§c".$val." §7KDR");
			}
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function topKsForm(Player $player):void{
		$form=new SimpleForm(function (Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->leaderboardsForm($player);
				break;
			}
		});
		$form->setTitle("§7Top KillStreak");
		$query=$this->plugin->main->query("SELECT * FROM essentialstats ORDER BY bestkillstreak DESC LIMIT 10;");
		while($resultArr=$query->fetchArray(SQLITE3_ASSOC)){
			$players=$resultArr['player'];
			$val=$this->plugin->getDatabaseHandler()->getTopKs($players);
			if(Utils::isShowInLeaderboardsEnabled($players)==true){
				$form->addButton("§2".$players."\n§c".$val." §7Best Streak");
			}
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function topEloForm(Player $player):void{
		$form=new SimpleForm(function (Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->leaderboardsForm($player);
				break;
			}
		});
		$form->setTitle("§7Top Elo");
		$query=$this->plugin->main->query("SELECT * FROM matchstats ORDER BY elo DESC LIMIT 10;");
		while($resultArr=$query->fetchArray(SQLITE3_ASSOC)){
			$players=$resultArr['player'];
			$val=$this->plugin->getDatabaseHandler()->getTopElo($players);
			if(Utils::isShowInLeaderboardsEnabled($players)==true){
				$form->addButton("§2".$players."\n§c".$val." §7elo");
			}
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function toysForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "size":
				$this->sizeForm($player);
				break;
				default:
				return;
			}
		});
		$form->setTitle("Toys");
		$form->addButton("Size\n§bBecome a midget or a giant", -1, "", "size");
		$player->sendForm($form);
	}
	public function sizeForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->toysForm($player);
				break;
				case "small":
				$player->setScale(0.5);
				break;
				case "normal":
				$player->setScale(1);
				break;
				case "medium":
				$player->setScale(1.5);
				break;
				case "large":
				$player->setScale(2);
				break;
			}
		});
		$form->setTitle("Size");
		$form->addButton("Small", -1, "", "small");
		$form->addButton("Normal", -1, "", "normal");
		$form->addButton("Medium", -1, "", "medium");
		$form->addButton("Large", -1, "", "large");
		$form->addButton("« Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function warpForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "nodebuff":
				//$this->nodebuffForm($player);
				$player->sendTo(1, true, true);
				break;
				case "gapple":
				//$this->gappleForm($player);
				$player->sendTo(2, true, true);
				break;
				case "opgapple":
				$player->sendTo(3, true, true);
				break;
				case "combo":
				$player->sendTo(4, true, true);
				break;
				case "fist":
				$player->sendTo(5, true, true);
				break;
                case "sumo":
                $player->sendTo(6, true, true);
                    $player->extinguish();
                    $player->setScale(1);
                    $player->setGamemode(2);
                    $player->setImmobile(false);
                    $player->setAllowFlight(false);
                    $player->setFlying(false);
                    $player->removeAllEffects();
                    $player->setXpLevel(0);
                    $player->setXpProgress(0.0);
                    $player->setFood(20);
                    $player->setHealth(20);
                    $player->getInventory()->setSize(36);
                    $player->getInventory()->clearAll();
                    $player->getArmorInventory()->clearAll();
                    $player->addEffect(new EffectInstance(Effect::getEffect(11), 99999, 4, true));
                    $player->getInventory()->setItem(8, Item::get(364, 0, 64));
                break;
				case "offline":
				$player->sendMessage("§cThis arena is currently offline.");
				break;
				case "wip":
				$player->sendMessage("§cThis arena is currently being fixed.");
				break;
			}
		});
		$nodebuff=$this->plugin->getServer()->getLevelByName("potpvp");
		//$nodebufflow=$this->plugin->getServer()->getLevelByName("nodebuff-low");
		//$nodebuffjava=$this->plugin->getServer()->getLevelByName("nodebuff-java");
		$gapple=$this->plugin->getServer()->getLevelByName("gapple");
		$opgapple=$this->plugin->getServer()->getLevelByName("opgapple");
		$combo=$this->plugin->getServer()->getLevelByName("combo");
		$fist=$this->plugin->getServer()->getLevelByName("fist");
        $sumo=$this->plugin->getServer()->getLevelByName("sumo");
		if(!$this->plugin->getServer()->isLevelLoaded("potpvp")){
			$count1="§cOffline";
			$c1="offline";
		}else{
			$totalnodebuff=count($this->plugin->getServer()->getLevelByName("potpvp")->getPlayers());
			$count1="§7Playing: §e".$totalnodebuff;
			$c1="nodebuff";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("gapple")){
			$count2="§cOffline";
			$c2="offline";
		}else{
			$totalgapple=count($gapple->getPlayers()) + count($opgapple->getPlayers());
			$count2="§7Playing: §e".$totalgapple;
			$c2="gapple";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("opgapple")){
			$count3="§cOffline";
			$c3="offline";
		}else{
			$count3="§7Playing: §e".count($opgapple->getPlayers());
			$c3="opgapple";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("combo")){
			$count4="§cOffline";
			$c4="offline";
		}else{
			$count4="§7Playing: §e".count($combo->getPlayers());
			$c4="combo";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("fist")){
			$count5="§cOffline";
			$c5="offline";
		}else{
			$count5="§7Playing: §e".count($fist->getPlayers());
			$c5="fist";
		}
        if(!$this->plugin->getServer()->isLevelLoaded("sumo")){
            $count6="§cOffline";
            $c6="offline";
        }else{
            $count6="§7Playing: §e".count($sumo->getPlayers());
            $c6="sumo";
        }
		$form->setTitle("§7FFA");
		$form->addButton("§dNoDebuff\n".$count1, 0, "textures/items/potion_bottle_splash_heal", $c1);
		$form->addButton("§dGapple\n".$count2, 0, "textures/items/apple_golden", $c2);
		//$form->addButton("OP Gapple\n".$count3, 0, "textures/items/nether_star", $c3);
		$form->addButton("§dCombo\n".$count4, 0, "textures/items/fish_pufferfish_raw", $c4);
		$form->addButton("§dFist\n".$count5, 0, "textures/items/beef_cooked", $c5);
        $form->addButton("§dSumo\n".$count6, 0, "textures/ui/slow_falling_effect", $c6);
		$player->sendForm($form);
	}
	/*public function nodebuffForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->warpForm($player);
				break;
				case "normal":
				$player->sendTo(1, true, true);
				break;
				case "lowkb":
				$player->sendTo(7, true, true);
				break;
				case "java":
				$player->sendTo(8, true, true);
				break;
				case "offline":
				$player->sendMessage("§cThis arena is currently offline.");
				break;
				case "wip":
				$player->sendMessage("§cThis arena is currently being fixed.");
				break;
			}
		});
		$normal=$this->plugin->getServer()->getLevelByName("nodebuff");
		$lowkb=$this->plugin->getServer()->getLevelByName("nodebuff-low");
		$java=$this->plugin->getServer()->getLevelByName("nodebuff-java");
		if(!$this->plugin->getServer()->isLevelLoaded("nodebuff")){
			$count1="§cOffline";
			$c1="offline";
		}else{
			$count1="Playing: ".count($normal->getPlayers());
			$c1="normal";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("nodebuff-low")){
			$count2="§cOffline";
			$c2="offline";
		}else{
			$count2="Playing: ".count($lowkb->getPlayers());
			$c2="lowkb";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("nodebuff-java")){
			$count3="§cOffline";
			$c3="offline";
		}else{
			$count3="Playing: ".count($java->getPlayers());
			$c3="java";
		}
		$form->setTitle("NoDebuff");
		$form->addButton("Normal\n".$count1, 0, "textures/items/potion_bottle_splash_heal", $c1);
		$form->addButton("Low KB\n".$count2, 0, "textures/items/potion_bottle_splash_heal", $c2);
		$form->addButton("Java\n".$count3, 0, "textures/items/potion_bottle_splash_heal", $c3);
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}*/
	/*public function gappleForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->warpForm($player);
				break;
				case "normal":
				$player->sendTo(2, true, true);
				break;
				case "op":
				$player->sendTo(3, true, true);
				break;
				case "offline":
				$player->sendMessage("§cThis arena is currently offline.");
				break;
				case "wip":
				$player->sendMessage("§cThis arena is currently being fixed.");
				break;
			}
		});
		$normal=$this->plugin->getServer()->getLevelByName("gapple");
		$op=$this->plugin->getServer()->getLevelByName("opgapple");
		if(!$this->plugin->getServer()->isLevelLoaded("gapple")){
			$count1="§cOffline";
			$c1="offline";
		}else{
			$count1="§7Playing: §e".count($normal->getPlayers());
			$c1="normal";
		}
		if(!$this->plugin->getServer()->isLevelLoaded("opgapple")){
			$count2="§cOffline";
			$c2="offline";
		}else{
			$count2="§7Playing: §e".count($op->getPlayers());
			$c2="op";
		}
		$form->setTitle("§7Gapple");
		$form->addButton("§eNormal Gapple\n".$count1, 0, "textures/items/apple_golden", $c1);
		$form->addButton("§eOP Gapple\n".$count2, 0, "textures/items/apple_golden", $c2);
		$form->addButton("§cBack", -1, "", "exit");
		$player->sendForm($form);
	}*/
	public function botDuelForm(Player $player):void{ 
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "easy":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					if($this->plugin->getDuelHandler()->isAnArenaOpen("easy")){
						$this->plugin->getDuelHandler()->createBotDuel($player, "Easy");
					}
				}else{
					$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
					if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "medium":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					if($this->plugin->getDuelHandler()->isAnArenaOpen("medium")){
						$this->plugin->getDuelHandler()->createBotDuel($player, "Medium");
					}
				}else{
					$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
					if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "hard":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					if($this->plugin->getDuelHandler()->isAnArenaOpen("hard")){
						$this->plugin->getDuelHandler()->createBotDuel($player, "Hard");
					}
				}else{
					$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
					if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "hacker":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					if($this->plugin->getDuelHandler()->isAnArenaOpen("hacker")){
						$this->plugin->getDuelHandler()->createBotDuel($player, "Hacker");
					}
				}else{
					$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
					if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
                case "punch":
                    if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
                        if($this->plugin->getDuelHandler()->isAnArenaOpen("punchbag")){
                            $this->plugin->getDuelHandler()->createBotDuel($player, "punchbag");
                        }
                    }else{
                        $result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
                        if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
                    }
                    break;
			}
		});
		$form->setTitle("§7Bot Duels");
		$form->addButton("§dEasy\n§7Reach: §e3", -1, "", "easy");
		$form->addButton("§dMedium\n§7Reach: §e3.5", -1, "", "medium");
		$form->addButton("§dHard\n§7Reach: §e3.8", -1, "", "hard");
		$form->addButton("§dHacker\n§7Reach: §e4.5", -1, "", "hacker");
        $form->addButton("§dPunching Bag\n§7No AI", -1, "", "punch");
		$player->sendForm($form);
	}
	public function duelForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "ranked":
				$this->rankedForm($player);
				break;
				case "unranked":
				$this->unrankedForm($player);
				break;
				case "duels":
				$this->spectateForm($player);
				break;
				case "leave":
				$this->plugin->getDuelHandler()->removePlayerFromQueue($player);
				break;
			}
		});
		$rankedqueued=0;
		$unrankedqueued=0;
		$queues=$this->plugin->getDuelHandler()->getQueuedPlayers();
		foreach($queues as $queue){
			if($queue->isRanked()){
				$rankedqueued++;
			}else{
				$unrankedqueued++;
			}
		}
		$rankedmatches=0;
		$unrankedmatches=0;
		$duels=$this->plugin->getDuelHandler()->getDuelsInProgress();
		foreach($duels as $duel){
			if($duel instanceof DuelGroup){
				if($duel->isRanked()){
					$rankedmatches++;
				}else{
					$unrankedmatches++;
				}
			}
		}
		$form->setTitle("§8Duels");
		$form->addButton("§8Unranked\n§7Queued: ".$unrankedqueued." | Matches: ".$unrankedmatches, -1, "", "unranked");
		$form->addButton("§8Ranked\n§7Queued: ".$rankedqueued." | Matches: ".$rankedmatches, -1, "", "ranked");
		$form->addButton("§8Spectate\n§7Ongoing Matches:§r §7".$this->plugin->getDuelHandler()->getNumberOfDuelsInProgress()."§7§r", -1, "", "duels");
		if($this->plugin->getDuelHandler()->isPlayerInQueue($player)){
			$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
			if(is_null($result)) return;
			$ranked=$result->isRanked();
			if($ranked===false){
				$ranked="Unranked";
			}
			if($ranked===true){
				$ranked="Ranked";
			}
			$queue=$result->getQueue();
			$form->setContent("§7You queued for ".$ranked." ".$queue."!");
			$form->addButton("§4Leave Queue", -1, "", "leave");
		}
		$player->sendForm($form);
	}
    public function customBotForm(Player $player):void{
        $form=new CustomForm(function(Player $player, $data=null):void{
            if ($data === null)
            {
                return;
            }
            if (sizeof($data) < 5 || sizeof($data) > 5)
            {
                return;
            }

            switch ($data[0]){
                case !is_numeric($data[0]): //is reach valid number
                    $player->sendMessage("Please enter a valid number (Reach)");
                    return;
                case is_numeric($data[0]):
                    if ($data[0] > 30 || $data[0] < 1)
                    {
                        $player->sendMessage("Please enter a valid number (Reach)");
                        return;
                    }
                    $data[0] += 0;
                    $data[0] = (float)$data[0];
                    break;

            }
            switch ($data[1])
            {
                case !is_numeric($data[1]): //is health valid number
                    $player->sendMessage("Please enter a valid number (Health)");
                    return;
                case is_numeric($data[1]):
                    if ($data[1] > 30 || $data[1] < 1)
                    {
                        $player->sendMessage("Please enter a valid number (Health)");
                        return;
                    }
                    $data[1] += 0;
                    $data[1] = (float)$data[1];

                    break;
            }
            switch ($data[2])
            {
                case !is_numeric($data[2]): //is accuracy valid number
                    $player->sendMessage("Please enter a valid number (Accuracy)");
                    return;
                case is_numeric($data[2]):
                    if ($data[2] > 100 || $data[2] < 1)
                    {
                        $player->sendMessage("Please enter a valid number (Accuracy)");
                        return;
                    }

                    $data[2] += 0;
                    $data[2] = (float)$data[2];
                    break;


            }
            switch ($data[3])
            {
                case !is_numeric($data[3]): //is potwait valid number
                    $player->sendMessage("Please enter a valid number (PotWait)");
                    return;
                case is_numeric($data[3]):
                    if ($data[3] > 30 || $data[3] < 1)
                    {
                        $player->sendMessage("Please enter a valid number (Pot Wait)");
                        return;
                    }

                    $data[3] += 0;
                    $data[3] = (float)$data[3];
                    break;


            }

            switch ($data[4])
            {
                case !is_numeric($data[3]): //is CPS valid number
                    $player->sendMessage("Please enter a valid number (CPS)");
                    return;
                case is_numeric($data[4]):
                    if ($data[4] > 100 || $data[4] < 0.1)
                    {
                        $player->sendMessage("Please enter a valid number (CPS)");
                        return;
                    }

                    $data[4] += 0;
                    $data[4] = (float)$data[4];
                    break;


            }

            if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)) {
                if ($this->plugin->getDuelHandler()->isAnArenaOpen("custom")) {
                    $this->plugin->getDuelHandler()->createCustomBotDuel($player, $data[0], $data[1], $data[2], $data[3], $data[4]);
                }
            }
        });
        $form->setTitle("§7Custom Bot Duels");
        $form->addInput("Reach (1-30)", "Default 4");
        $form->addInput("Bot Health (1-30)", "Default 20");
        $form->addInput("Accuracy (1 - 100 how accurate the aiming is)", "Default 50");
        $form->addInput("Pot Wait (1 - 20 how much time after pot uses pots.)", "Default 5 seconds");
        $form->addInput("CPS (0 - 100 Attack Cooldown of the bot, so if you type 1, the bot will hit you every 1 second. Decimals e.g 0.4 are allowed.)", "Default 6 seconds");
        $player->sendForm($form);
    }
	public function rankedForm(Player $player):void{ 
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "nodebuff":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "NoDebuff", true); //true for ranked
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "gapple":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Gapple", true);
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "soup":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Soup", true);
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "builduhc":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "BuildUHC", true);
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
                case "sumo":
                    if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
                        $this->plugin->getDuelHandler()->addPlayerToQueue($player, "Sumo", true);
                    }else{
                        $result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
                        if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
                    }
                    break;
				case "leave":
				$this->plugin->getDuelHandler()->removePlayerFromQueue($player);
				break;
				case "exit":
				$this->duelForm($player);
				break;
			}
		});
		$nodebuffqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("NoDebuff", true);
		$nodebuffplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("NoDebuff", true);
		$gapplequeued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Gapple", true);
		$gappleplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Gapple", true);
		$soupqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Soup", true);
		$soupplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Soup", true);
		$builduhcqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("BuildUHC", true);
		$builduhcplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("BuildUHC", true);
        $sumoqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Sumo", true);
        $sumoplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Sumo", true);
		$form->setTitle("§7Ranked");
		$form->addButton("§dNoDebuff\n§7Queued: ".$nodebuffqueued." | Matches: ".$nodebuffplaying, 0, "textures/items/potion_bottle_splash_heal", "nodebuff");
		$form->addButton("§dGapple\n§7Queued: ".$gapplequeued." | Matches: ".$gappleplaying, 0, "textures/items/apple_golden", "gapple");
		$form->addButton("§dSoup\n§7Queued: ".$soupqueued." | Matches: ".$soupplaying, 0, "textures/items/mushroom_stew", "soup");
		$form->addButton("§dBuildUHC\n§7Queued: ".$builduhcqueued." | Matches: ".$builduhcplaying, 0, "textures/items/bucket_lava", "builduhc");
        $form->addButton("§dSumo\n§7Queued: ".$sumoqueued." | Matches: ".$sumoplaying, 0, "textures/ui/slow_falling_effect", "sumo");
		$form->addButton("§4Back", -1, "", "exit");
		if($this->plugin->getDuelHandler()->isPlayerInQueue($player)){
			$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
			if(is_null($result)) return;
			$ranked=$result->isRanked();
			if($ranked===false){
				$ranked="Unranked";
			}
			if($ranked===true){
				$ranked="Ranked";
			}
			$queue=$result->getQueue();
			$form->setContent("§7You queued for ".$ranked." ".$queue.".");
			$form->addButton("§4Leave Queue", -1, "", "leave");
		}
		$player->sendForm($form);
	}
	public function unrankedForm(Player $player):void{ 
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "nodebuff":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "NoDebuff", false); //false for unranked
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "gapple":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Gapple", false); //false for unranked
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "soup":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Soup", false);
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "builduhc":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "BuildUHC", false);
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "combo":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Combo", false); //false for unranked
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "sumo":
				if(!$this->plugin->getDuelHandler()->isPlayerInQueue($player) and !$this->plugin->getDuelHandler()->isInDuel($player)){
					$this->plugin->getDuelHandler()->addPlayerToQueue($player, "Sumo", false); //false for unranked
					}else{
						$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
						if(!is_null($result)) $player->sendMessage("§cYou are already in a queue!");
				}
				break;
				case "leave":
				$this->plugin->getDuelHandler()->removePlayerFromQueue($player);
				break;
				case "exit":
				$this->duelForm($player);
				break;
			}
		});
		$nodebuffqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("NoDebuff", false);
		$nodebuffplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("NoDebuff", false);
		$gapplequeued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Gapple", false);
		$gappleplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Gapple", false);
		$soupqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Soup", false);
		$soupplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Soup", false);
		$builduhcqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("BuildUHC", false);
		$builduhcplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("BuildUHC", false);
		$comboqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Combo", false);
		$comboplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Combo", false);
		$sumoqueued=$this->plugin->getDuelHandler()->getNumberQueuedFor("Sumo", false);
		$sumoplaying=$this->plugin->getDuelHandler()->getNumberOfDuelsOfQueue("Sumo", false);
		$form->setTitle("§7Unranked");
		$form->addButton("§dNoDebuff\n§7Queued: ".$nodebuffqueued." | Matches: ".$nodebuffplaying, 0, "textures/items/potion_bottle_splash_heal", "nodebuff");
		$form->addButton("§dGapple\n§7Queued: ".$gapplequeued." | Matches: ".$gappleplaying, 0, "textures/items/apple_golden", "gapple");
		$form->addButton("§dSoup\n§7Queued: ".$soupqueued." | Matches: ".$soupplaying, 0, "textures/items/mushroom_stew", "soup");
		$form->addButton("§dBuildUHC\n§7Queued: ".$builduhcqueued." | Matches: ".$builduhcplaying, 0, "textures/items/bucket_lava", "builduhc");
		//$form->addButton("§cCombo\n§7Queued: ".$comboqueued." | Matches: ".$comboplaying, 0, "textures/items/fish_pufferfish_raw", "combo");
		$form->addButton("§cSumo\n§7Queued: ".$sumoqueued." | Matches: ".$sumoplaying, 0, "textures/ui/slow_falling_effect", "sumo");
		$form->addButton("§4Back", -1, "", "exit");
		if($this->plugin->getDuelHandler()->isPlayerInQueue($player)){
			$result=$this->plugin->getDuelHandler()->getQueuedPlayer($player);
			if(is_null($result)) return;
			$ranked=$result->isRanked();
			if($ranked===false){
				$ranked="Unranked";
			}
			if($ranked===true){
				$ranked="Ranked";
			}
			$queue=$result->getQueue();
			$form->setContent("§7You are queued for ".$ranked." ".$queue.".");
			$form->addButton("§4Leave Queue", -1, "", "leave");
		}
		$player->sendForm($form);
	}
	public function spectateForm(Player $player):void{ 
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->duelForm($player);
				return;
				break;
				case 0:
				$duel=null;
				$this->targetDuel[Utils::getPlayerName($player)]=$data;
				$normal=$this->plugin->getDuelHandler()->getDuel($data);
				$party=$this->plugin->getDuelHandler()->getPartyDuel($data);
				if($normal===null){
					$duel=$party;
				}elseif($party===null){
					$duel=$normal;
				}
				if($this->plugin->getDuelHandler()->isInDuel($player) or $this->plugin->getDuelHandler()->isInPartyDuel($player)){
					$player->sendMessage("§cError, retry!");
				}else{
					if($duel!==null) $duel->addSpectator($player);
				}
				break;
			}
		});
		$form->setTitle("§7Spectate");
		foreach($this->plugin->getDuelHandler()->getDuelsInProgress() as $duel){
			if($duel instanceof DuelGroup){
				$p=$duel->getPlayer();
				$o=$duel->getOpponent();
				$playerDS=Utils::getPlayerDisplayName($p);
				$opponentDS=Utils::getPlayerDisplayName($o);
				$queue=$duel->getQueue();
				$ranked=$duel->isRanked();
				if($ranked===true){
					$ranked="Ranked";
				}else{
					$ranked="Unranked";
				}
			}
			$form->addButton("§a".$playerDS." §7vs §c".$opponentDS."\n§7".$ranked." ".$queue, -1, "", $duel->getPlayerName());
		}
		foreach($this->plugin->getDuelHandler()->getPartyDuelsInProgress() as $duel){
			if($duel instanceof PartyDuelGroup){
				$party=$duel->getParty()->getName();
				$queue=$duel->getQueue();
				$allowspecs=$duel->getAllowSpecs();
			}
			if($allowspecs===true) $form->addButton("§a".$party."§7's Party\n§7".$queue, -1, "", $duel->getParty()->getLeader());
		}
		$form->addButton("§4Back", -1, "", "exit");
		$player->sendForm($form);
	}
}
