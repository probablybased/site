<?php

declare(strict_types=1);

namespace Ghezin\cp\tasks;

use pocketmine\scheduler\Task;
use Ghezin\cp\Core;
use Ghezin\cp\Utils;
use pocketmine\Player;
use pocketmine\Server;

class PingTask extends Task{
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}
	
	public function onRun(int $tick):void{
		
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
			$plevel = $player->getLevel()->getName();
			
			if($plevel == "potpvp" or $plevel == "gapple" or $plevel == "combo" or $plevel == "fist"){
				if($this->plugin->getScoreboardHandler()->isPlayerSetScoreboard($player)){
					if($this->plugin->getScoreboardHandler()->isPlayerSetFfa($player)){
						$this->plugin->getScoreboardHandler()->updateFfaLine($player);
					}
				}
			}
			
			if($plevel == "lobby"){
				if($this->plugin->getScoreboardHandler()->isPlayerSetScoreboard($player)){
					if($this->plugin->getScoreboardHandler()->isPlayerSetMain($player)){
						$this->plugin->getScoreboardHandler()->updateMainLinePing($player);
					}
				}
			}
			
			if($plevel == "duel1" or $plevel == "duel2" or $plevel == "duel3" or $plevel == "duel4" or $plevel == "duel5" or $plevel == "duel1"){
				if($this->plugin->getScoreboardHandler()->isPlayerSetScoreboard($player)){
					if($this->plugin->getScoreboardHandler()->isPlayerSetDuel($player)){
						$this->plugin->getScoreboardHandler()->updateDuelLine($player);
					}
				}
			}
	    }
    }
		/*foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
			$this->plugin->getScoreboardHandler()->updateMainLinePing($online);
		}*/
}

/*if($this->plugin->getScoreboardHandler()->isPlayerSetScoreboard($online)){
			if($this->plugin->getScoreboardHandler()->isPlayerSetFfa($online)){
			    $this->plugin->getScoreboardHandler()->updateFfaLine($online);
			} elseif($this->plugin->getScoreboardHandler()->isPlayerSetMain($online)){
			    foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
			    $this->plugin->getScoreboardHandler()->updateMainLinePing($online);
		        }
			    }
		}*/