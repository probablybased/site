<?php
namespace Ghezin\cp\Query;

DEFINE ('DB_USER', 'astralpvp');

DEFINE ('DB_PASSWORD', 'ndbnvQ6ZeNv9kOl');

DEFINE ('DB_HOST', 'mysql.astralclient.net');

DEFINE ('DB_NAME', 'astralpvp');

class db_connect
{
    public $dbc;
    public function __construct()
    {
        $dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)

        or die('Could not connect to MySQL: ' .
            mysqli_connect_error());
    }
}

class query
{
    public $user;
    public $response;
    public function __construct(String $user)
    {
        $this->user = $user;
    }
    public function fetch(String $user)
    {
        $query = "SELECT * FROM STATS where USERNAME like ‘%${user}’";
        $dbc = new db_connect();
        $this->response = @mysqli_query($dbc->dbc, $query);
    }
    public function put(String $query)
    {
        $dbc = new db_connect();
        $this->response = @mysqli_query($dbc->dbc, $query);
    }
}