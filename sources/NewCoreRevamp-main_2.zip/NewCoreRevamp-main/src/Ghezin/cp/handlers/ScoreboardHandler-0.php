<?php

declare(strict_types=1);

namespace Ghezin\cp\handlers;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use Ghezin\cp\Core;
use Ghezin\cp\Utils;

class ScoreboardHandler{
	
	private $plugin;
	private $scoreboard=[];
	private $main=[];
	private $duel=[];
	private $spectator=[];

	public function __construct(){
		$this->plugin=Core::getInstance();
	}
	public function sendMainScoreboard($player, string $title="Practice"):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$this->lineTitle($player, "  "."§r§5Astral§dPvP§r §7(NA) ");
		/*$this->lineCreate($player, 0, str_repeat(" ", 3));
		$this->lineCreate($player, 1, "§7➺ Welcome §a".$player->getName());
		$this->lineCreate($player, 2, str_repeat(" ", 5));
		$this->lineCreate($player, 3, "§7➺ Kill(s)§7: §a".$this->plugin->getDatabaseHandler()->getKills($player));
		$this->lineCreate($player, 4, "§7➺ Death(s)§7: §a".$this->plugin->getDatabaseHandler()->getDeaths($player));
		$this->lineCreate($player, 5, "§7➺ KDR§7: §a".$this->plugin->getDatabaseHandler()->getKdr($player));
		$this->lineCreate($player, 6, "§7➺ Killstreak§7: §a".$this->plugin->getDatabaseHandler()->getKillstreak($player));
		$this->lineCreate($player, 7, "§7➺ Combat§7: §a0");
		$this->lineCreate($player, 8, "§7➺ Ping§7: §a".$player->getPing());
		$this->lineCreate($player, 9, "");
		$this->lineCreate($player, 10, "§7➺ §a".$this->plugin->getIp()."");*/
		$online = count($this->plugin->getServer()->getOnlinePlayers());
		$playing = $this->plugin->getDuelHandler()->getNumberOfDuelsInProgress();
		$queued = $this->plugin->getDuelHandler()->getNumberOfQueuedPlayers();
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§rOnline: §d$online");
		$this->lineCreate($player, 2, "§rPlaying: §d$playing");
		$this->lineCreate($player, 3, "");
		$this->lineCreate($player, 4, "§d".$this->plugin->getIp()."");
		$this->lineCreate($player, 5, ("§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->main[$player->getName()]=$player->getName();
	}
	public function sendFfaScoreboard($player):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$cl = $player->getLevel()->getName();
		if($cl == "potpvp"){
			$fw = "NoDebuff";
		} elseif ($cl == "gapple"){
			$fw = "Gapple";
		} elseif ($cl == "combo"){
			$fw = "Combo";
		} elseif ($cl == "fist"){
			$fw = "Fist";
		}
		$this->lineTitle($player, "  §r§5Astral§dPvP§r §7(AS)  ");
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§rPlaying FFA:");
		$this->lineCreate($player, 2, "§d$fw");
		$this->lineCreate($player, 3, "    ");
		$this->lineCreate($player, 4, "§rKillstreak: §d".$this->plugin->getDatabaseHandler()->getKillstreak($player));
		$this->lineCreate($player, 5, "§rPlayers: §d".count($player->getLevel()->getPlayers()));
		$this->lineCreate($player, 6, "         ");
		$this->lineCreate($player, 7, "§rYour Ping: §d".$player->getPing());
		$this->lineCreate($player, 8, "");
		$this->lineCreate($player, 9, "§d".$this->plugin->getIp()."");
		$this->lineCreate($player, 10, ("§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->ffa[$player->getName()]=$player->getName();
		
	}
	public function sendDuelScoreboard($player, string $type, string $queue, string $opponent):void{
		/*$this->lineCreate($player, 1, "§7".$type.": §a".$queue);
		$this->lineCreate($player, 2, "    ");
		$this->lineCreate($player, 1, "§7➺ §7Fighting: §r".$opponent);
		$this->lineCreate($player, 2, "§7➺ §7Duration: §r00:00");
		$this->lineCreate($player, 3, "         ");*/
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$pping = $player->getPing();
		$opponentqueue = $this->plugin->getDuelHandler()->getQueuedPlayer($opponent);
		$o = $opponentqueue->getPlayer();
		$oping = $o->getPing();
		$this->lineTitle($player, "  §r§5Astral§dPvP§r §7(AS)  ");
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§rYour Ping: §d$pping");
		$this->lineCreate($player, 2, "§rTheir Ping: §d$oping");
		$this->lineCreate($player, 3, "    ");
		$this->lineCreate($player, 4, "§d".$this->plugin->getIp());
		$this->lineCreate($player, 5, ("§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->duel[$player->getName()]=$player->getName();
	}
	public function sendPartyDuelScoreboard($player, string $queue, int $alive, int $playing):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$this->lineTitle($player, "  §r§5Astral§dPvP§r §7(AS)  ");
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§rParty: §d".$queue);
		$this->lineCreate($player, 2, "    ");
		$this->lineCreate($player, 3, "§rAlive: §d".$alive."§7/§d".$playing);
		$this->lineCreate($player, 4, "§rDuration: §d00:00");
		$this->lineCreate($player, 5, "         ");
		$this->lineCreate($player, 6, "§d".$this->plugin->getIp());
		$this->lineCreate($player, 7, ("§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->duel[$player->getName()]=$player->getName();
	}
	public function sendBotDuelScoreboard($player, string $opponent):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$this->lineTitle($player, "  §r§5Astral§dPvP§r §7(AS)  ");
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§rFighting: §dBot");
		$this->lineCreate($player, 2, "§rDuration: §d00:00");
		$this->lineCreate($player, 3, "         ");
		$this->lineCreate($player, 4, "§d".$this->plugin->getIp());
		$this->lineCreate($player, 5, ("§r§r§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->botduel[$player->getName()]=$player->getName();
	}
	public function sendDuelSpectateScoreboard($player, string $type, string $queue, string $duelplayer, string $duelopponent):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$this->lineTitle($player, "  §r§5Astral§dPvP§r §7(AS)  ");
		$this->lineCreate($player, 0, ("§r§r§r§r§r§r§r§r§r--------------------"));
		$this->lineCreate($player, 1, "§r".$type.": §d".$queue);
		$this->lineCreate($player, 2, "    ");
		$this->lineCreate($player, 3, "§rMatch: §a".$duelplayer." §7vs§c ".$duelopponent);
		$this->lineCreate($player, 4, "         ");
		$this->lineCreate($player, 5, "§d".$this->plugin->getIp());
		$this->lineCreate($player, 6, ("§r§r§r§r§r§r§r--------------------"));
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->spectator[$player->getName()]=$player->getName();
	}
	public function sendPartyDuelSpectateScoreboard($player, string $queue, string $leader):void{
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			$this->removeScoreboard($player);
		}
		$this->lineTitle($player, "  §l§5SPECTATOR  ");
		$this->lineCreate($player, 0, " ");
		$this->lineCreate($player, 1, "§rParty: §d".$queue);
		$this->lineCreate($player, 2, "    ");
		$this->lineCreate($player, 3, "§rLeader: §d".$leader);
		$this->lineCreate($player, 4, "         ");
		$this->lineCreate($player, 5, "§d".$this->plugin->getIp());
		$this->scoreboard[$player->getName()]=$player->getName();
		$this->spectator[$player->getName()]=$player->getName();
	}
	public function updateMainLineWelcome($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 4);
				$this->lineCreate($player, 4, "§d".$this->plugin->getIp());
			}
		}
	}
	
	public function updateMainLineCombat($player, $timer){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				//$online = count($this->plugin->getServer()->getOnlinePlayers());
		        $playing = $this->plugin->getDuelHandler()->getNumberOfDuelsInProgress();
				$this->lineRemove($player, 2);
				$this->lineCreate($player, 2, "§rPlaying: §a$playing");
			}
			if($this->isPlayerSetMain($player)){
				$online = count($this->plugin->getServer()->getOnlinePlayers());
		        //$playing = $this->plugin->getDuelHandler()->getNumberOfDuelsInProgress();
				$this->lineRemove($player, 1);		
				$this->lineCreate($player, 1, "§rOnline: §a$online");
			}
		}*/
	}
	
	public function updateMainLineKills($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 3);
				$this->lineCreate($player, 3, "§7➺ Kill(s)§7: §a".$this->plugin->getDatabaseHandler()->getKills($player));
			}
		}*/
	}
	public function updateMainLineDeaths($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 4);
				$this->lineCreate($player, 4, "§7➺ Death(s)§7: §a".$this->plugin->getDatabaseHandler()->getDeaths($player));
			}
		}*/
	}
	public function updateMainLineKdr($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 5);
				$this->lineCreate($player, 5, "§7➺ KDR§7: §a".$this->plugin->getDatabaseHandler()->getKdr($player));
			}
		}*/
	}
	public function updateMainLineKillstreak($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 6);
				$this->lineCreate($player, 6, "§7➺ Killstreak§7: §a".$this->plugin->getDatabaseHandler()->getKillstreak($player));
			}
		}*/
	}
	
	public function updateMainLinePing($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				//$online = count($this->plugin->getServer()->getOnlinePlayers());
				$queued = $this->plugin->getDuelHandler()->getNumberOfQueuedPlayers();
		        $playing = $this->plugin->getDuelHandler()->getNumberOfDuelsInProgress();
				$this->lineRemove($player, 2);
				$this->lineCreate($player, 2, "§rPlaying: §d$playing");
			}
			if($this->isPlayerSetMain($player)){
				$online = count($this->plugin->getServer()->getOnlinePlayers());
				//$queued = $this->plugin->getDuelHandler()->getNumberOfQueuedPlayers();
		        //$playing = $this->plugin->getDuelHandler()->getNumberOfDuelsInProgress();
				$this->lineRemove($player, 1);		
				$this->lineCreate($player, 1, "§rOnline: §d$online");
			}
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 8);
				$this->lineCreate($player, 8, "§7➺ Ping§7: §a".$player->getPing());
			}*/
			/*if($this->isPlayerSetDuel($player)){
				$this->lineRemove($player, 4);
				$this->lineCreate($player, 4, "§7➺ §a".$this->plugin->getIp());
			}
		}*/
	}
	
	public function updateFfaLine($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetFfa($player)){
				$this->lineRemove($player, 4);
				$this->lineCreate($player, 4, "§rKillstreak: §d".$this->plugin->getDatabaseHandler()->getKillstreak($player));
			}
			if($this->isPlayerSetFfa($player)){
				$this->lineRemove($player, 5);
				$this->lineCreate($player, 5, "§rPlayers: §d".count($player->getLevel()->getPlayers()));
			}
			if($this->isPlayerSetFfa($player)){
				$this->lineRemove($player, 7);
				$this->lineCreate($player, 7, "§rYour Ping: §d".$player->getPing());
			}
			if($this->isPlayerSetMain($player)){
				$this->lineRemove($player, 3);
				$this->lineCreate($player, 3, "");
			}
		}
	}
	
	public function updateDuelLine($player){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetDuel($player)){
				$pping = $player->getPing();
				$this->lineRemove($player, 1);
				$this->lineCreate($player, 1, "§rYour Ping: §d$pping");
			}
		}
	}

	public function updateBotDuelDuration($player, $duration){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetBotDuel($player)){
				$this->lineRemove($player, 2);
				$this->lineCreate($player, 2, "§rDuration: §d".$duration);
			}
		}
	}
	public function updateDuelDuration($player, $duration){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		/*if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetDuel($player)){
				$this->lineRemove($player, 2);
				$this->lineCreate($player, 2, "§rDuration: §a".$duration);
			}
		}*/
	}
	public function updatePartyDuelAlive($player, $alive, $playing){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		if($this->isPlayerSetScoreboard($player)){
			if($this->isPlayerSetDuel($player)){
				$this->lineRemove($player, 3);
				$this->lineCreate($player, 3, "§rAlive: §d".$alive."§7/§d".$playing);
			}
		}
	}
	public function isPlayerSetScoreboard($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->scoreboard[$name]);
	}
	public function isPlayerSetMain($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->main[$name]);
	}
	public function isPlayerSetDuel($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->duel[$name]);
	}
	public function isPlayerSetFfa($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->ffa[$name]);
	}
	public function isPlayerSetBotDuel($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->botduel[$name]);
	}
	public function isPlayerSetSpectator($player):bool{
		$name=Utils::getPlayerName($player);
		return ($name !== null) and isset($this->spectator[$name]);
	}
	public function lineTitle($player, string $title){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		$packet=new SetDisplayObjectivePacket();
		$packet->displaySlot="sidebar";
		$packet->objectiveName="objective";
		$packet->displayName=$title;
		$packet->criteriaName="dummy";
		$packet->sortOrder=0;
		$player->sendDataPacket($packet);
	}
	public function removeScoreboard($player){
		$player=Utils::getPlayer($player);
		$packet=new RemoveObjectivePacket();
		$packet->objectiveName="objective";
		$player->sendDataPacket($packet);
		unset($this->scoreboard[$player->getName()]);
		unset($this->main[$player->getName()]);
		unset($this->duel[$player->getName()]);
		unset($this->spectator[$player->getName()]);
	}
	public function lineCreate($player, int $line, string $content){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		$packetline=new ScorePacketEntry();
		$packetline->objectiveName="objective";
		$packetline->type=ScorePacketEntry::TYPE_FAKE_PLAYER;
		$packetline->customName=" ".$content."   ";
		$packetline->score=$line;
		$packetline->scoreboardId=$line;
		$packet=new SetScorePacket();
		$packet->type=SetScorePacket::TYPE_CHANGE;
		$packet->entries[]=$packetline;
		$player->sendDataPacket($packet);
	}
	public function lineRemove($player, int $line){
		$player=Utils::getPlayer($player);
		if(Utils::isScoreboardEnabled($player)==false){
			return;
		}
		$entry=new ScorePacketEntry();
		$entry->objectiveName="objective";
		$entry->score=$line;
		$entry->scoreboardId=$line;
		$packet=new SetScorePacket();
		$packet->type=SetScorePacket::TYPE_REMOVE;
		$packet->entries[]=$entry;
		$player->sendDataPacket($packet);
	}
}