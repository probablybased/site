<?php


namespace Ghezin\cp\bots;


use pocketmine\block\Liquid;
use pocketmine\entity\Attribute;
use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Player;

class PunchingBag extends Human
{

    public function __construct(Level $level, CompoundTag $nbt){
        parent::__construct($level, $nbt);
        $this->setMaxHealth($this->getMaxHealth());
        $this->setHealth(20);
        $this->setNametag("Punching Bag");
        $this->generateRandomPosition();
    }

    public function generateRandomPosition(){
        $minX=$this->getFloorX() - 8;
        $minY=$this->getFloorY() - 8;
        $minZ=$this->getFloorZ() - 8;
        $maxX=$minX + 16;
        $maxY=$minY + 16;
        $maxZ=$minZ + 16;
        $level=$this->getLevel();
        for($attempts=0; $attempts < 16; ++$attempts){
            $x=mt_rand($minX, $maxX);
            $y=mt_rand($minY, $maxY);
            $z=mt_rand($minZ, $maxZ);
            while($y >= 0 and !$level->getBlockAt($x, $y, $z)->isSolid()){
                $y--;
            }
            if($y < 0){
                continue;
            }
            $blockUp=$level->getBlockAt($x, $y + 1, $z);
            $blockUp2=$level->getBlockAt($x, $y + 2, $z);
            if($blockUp->isSolid() or $blockUp instanceof Liquid or $blockUp2->isSolid() or $blockUp2 instanceof Liquid){
                continue;
            }
            break;
        }
        $this->randomPosition=new Vector3($x, $y + 1, $z);
    }

    public function attack(EntityDamageEvent $source):void{
        parent::attack($source);
        if($source->isCancelled()){
            $source->setCancelled();
            return;
        }
        if($source instanceof EntityDamageByEntityEvent){
            $killer=$source->getDamager();
            if($killer instanceof Player){
                if($killer->isSpectator()){
                    $source->setCancelled(true);
                    return;
                }
                $deltaX=$this->x - $killer->x;
                $deltaZ=$this->z - $killer->z;
                $this->knockBack($killer, 0, $deltaX, $deltaZ);
                $this->setHealth($this->getMaxHealth()); //Heal
            }
        }
    }

    public function knockBack($damager, float $damage, float $x, float $z, float $base=0.4):void{
        $xzKB=0.46;
        $yKb=0.5;
        $f=sqrt($x * $x + $z * $z);
        if($f <= 0){
            return;
        }
        if(mt_rand() / mt_getrandmax() > $this->getAttributeMap()->getAttribute(Attribute::KNOCKBACK_RESISTANCE)->getValue()){
            $f=1 / $f;
            $motion=clone $this->motion;
            $motion->x /= 1;
            $motion->y /= 1;
            $motion->z /= 1;
            $motion->x += $x * $f * $xzKB;
            $motion->y += $yKb;
            $motion->z += $z * $f * $xzKB;
            if($motion->y > $yKb){
                $motion->y = $yKb;
            }
            if($this->isAlive() and !$this->isClosed()) $this->move($motion->x * 1.1, $motion->y * 1.5, $motion->z * 1.1);
        }
    }
}