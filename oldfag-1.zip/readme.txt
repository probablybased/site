       .__       .___ _____                
  ____ |  |    __| _// ____\____     ____  
 /  _ \|  |   / __ |\   __\\__  \   / ___\ 
(  <_> )  |__/ /_/ | |  |   / __ \_/ /_/  >
 \____/|____/\____ | |__|  (____  /\___  / 
                  \/            \//_____/ 

cracked by based#0005

lol this was easy as shit holy shit you fucking suck (20 seconds 🤣)

reason: furry on dev team lol